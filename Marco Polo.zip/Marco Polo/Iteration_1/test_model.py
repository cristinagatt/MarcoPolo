from web_env.envs.web_env import Web_Env 

import pathlib
import pickle
import tempfile

import stable_baselines3 as sb3

from imitation.algorithms import bc
from imitation.data import rollout
from imitation.util import logger, util
from stable_baselines3.common.vec_env import DummyVecEnv

import gym

env = DummyVecEnv([lambda: Web_Env()])

model= bc.reconstruct_policy("abebooks_login_policy")

obs = env.reset()
i=0
dones=False
while not dones and i<=200:
    action, _states = model.predict(obs)
    obs, rewards, dones, info = env.step(action)
    i+=1
    if (dones):
        print("All done")
        env.render()
        break
