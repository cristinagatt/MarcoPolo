import gym
from gym import spaces
import numpy as np
import time
import math
from random import randint

from selenium import webdriver
from selenium.common.exceptions import StaleElementReferenceException, NoSuchElementException, ElementNotInteractableException
from selenium.webdriver.firefox.options import Options
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.support.ui import Select

from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys

from web_driver_classes import Element_Classifier


class Drv():
    def __init__(self,url):
        self.driver=None
        self.current_element=-1
        self.items_in_cart=0
        self.options=0
        self.url=url
        self.relevant_elements=[]
        self.classifier=None

        self.elements={0: "addtocart", 
        1: "login", 2: "username",
        3: "password", 4: "continue", 5:"account",
        6: "search", 7:"checkout", 8: "productlisting", 9: "menu", 
        10: "menuitem", 11:"submenuitem", 12: "removefromcart", 13: "basket"}

    def reset(self):
        if(self.driver!=None):
            time.sleep(2)
            self.driver.close()
        
        self.load_browser()
        self.get_relevant_elements()

    def load_browser(self):
        self.driver=webdriver.Firefox()
        self.driver.get(self.url)

    def get_relevant_elements(self):
        time.sleep(2)
        relevant_elements=[]
        elements=self.load_all_elements()
        self.classifier= Element_Classifier.Classifier(elements,self.url)
        self.relevant_elements=self.classifier.classify()

    def load_all_elements(self):
        tags=[]
        if(self.url=="https://amazon.com"):
            tags=['//a', '//input', '//button', '//span']
        elif(self.url=="https://walmart.com"):
            tags=['//a', '//input', '//button']
        elif (self.url=="https://abebooks.com"):
            tags=['//a', '//input', '//button'] 
        elif (self.url=="https://alibris.com"):
            tags=['//input', "//a",'//button', "//td", "//p"]

        final_elements=[]
        for tag in tags:
            elements=self.driver.find_elements_by_xpath(tag)
            final_elements.extend(elements)

        return final_elements

    def map_element(self,element):
        labelled_elements=[elem for elem in self.relevant_elements if elem['label']==element]
        labelled_elements.sort(key=lambda y: y['cosine'], reverse=True)
        print(labelled_elements)
        return labelled_elements

    def click(self,element,element_label):
        unsuccessful=False

        web_elements=self.map_element(element_label)

        for web_element in web_elements:
            web_element=web_element['element']

            if(web_element!=0):
                try:
                    web_element.click()

                    if(element==0): #Add to cart
                        self.items_in_cart+=1
                    break
                except Exception as e:
                    print("take 2")
                    try:
                        self.driver.execute_script("arguments[0].click()", web_element)
                        unsuccessful=False
                        if(element==0):
                            self.items_in_cart+=1
                        if(element==12):
                            self.items_in_cart+=(-1)
                        break
                    except Exception as e:
                        print("Unsuccessful")
                        unsuccessful=True
            else:
                unsuccessful=True
        time.sleep(2)
        if(unsuccessful):
            element=-1
        self.current_element=element
        self.get_relevant_elements()
        return element
    
    def send_keys(self,element,input,element_label,enter):
        unsuccessful=False
        web_elements=self.map_element(element_label)
        for web_element in web_elements:
            web_element=web_element['element']
            if(web_element!=0):
                try:
                    if(not enter):
                        web_element.send_keys(input)
                    elif (enter):
                        
                        web_element.send_keys(input,Keys.ENTER)
                    unsuccessful=False
                    break
                except Exception as e:
                    print("KEYS UNSUCCESSFUL")
                    unsuccessful=True
        time.sleep(2)
        if(unsuccessful):
            element=-1
        self.current_element=element
        self.get_relevant_elements()
        return element
