import gym
from gym import spaces
import numpy as np
import time
import math
from random import randint

from selenium import webdriver
from selenium.common.exceptions import StaleElementReferenceException, NoSuchElementException, ElementNotInteractableException
from selenium.webdriver.firefox.options import Options
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.support.ui import Select

from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys

from web_driver_classes import Element_Classifier


class Drv():
    def __init__(self,url):
        self.driver=None
        self.current_element=-1
        self.items_in_cart=0
        self.options=0
        self.url=url
        self.relevant_elements=[]
        self.classifier=None
        self.previous_element=-2
        self.cookies=0
        self.popup=0
        self.unsuccessful=False

        self.elements={0: "addtocart", 
        1: "login", 2: "username",
        3: "password", 4: "continue", 5:"account",
        6: "search", 7:"checkout", 8: "productlisting", 9: "menu", 
        10: "menuitem", 11:"submenuitem", 12: "removefromcart", 13: "basket",
        14: "cookies", 15: "allow", 16: "close"}

    def reset(self):
        if(self.driver!=None):

            time.sleep(2)
            self.driver.close()    
        self.load_browser()
        self.get_relevant_elements()
        self.detect_cookies()
        self.detect_popup()

    def load_browser(self):
        self.driver=webdriver.Firefox()
        self.driver.get(self.url)

    def get_relevant_elements(self):
        if(not self.unsuccessful):
            time.sleep(4)
            relevant_elements=[]
            elements=self.load_all_elements()
            #self.classifier= Element_Classifier.Classifier(elements,self.url)
            #self.relevant_elements=self.classifier.classify()
            print(self.relevant_elements)

    def load_all_elements(self):
        tags=[]
        if(self.url=="https://amazon.com"):
            tags=['//a', '//input', '//button', '//span']
        elif(self.url=="https://walmart.com"):
            tags=['//a', '//input', '//button']
        elif (self.url=="https://abebooks.com"):
            tags=['//a', '//input', '//button'] 
        elif (self.url=="https://alibris.com"):
            tags=['//input', "//a",'//button', "//td", "//p"]
        elif (self.url=="https://manomano.co.uk"):
            tags=['//input', '//a', '//button','//h2']
        elif(self.url=="https://newegg.com"):
            tags=['//input', '//a', '//button', '//p']
        elif(self.url=="https://www.barnesandnoble.com"):
            tags=['//input', '//a', '//button', '//iframe','//p']
        
        final_elements=[]
        self.classifier= Element_Classifier.Classifier(self.url)
        for tag in tags:
            if(tag!="//iframe"):
                elements=self.driver.find_elements_by_xpath(tag)
                final_elements.extend(elements)
        self.relevant_elements=self.classifier.classify(final_elements)

        if("//iframe" in tags): 
                elements=self.driver.find_elements_by_xpath("//iframe")             
                print("NO OF IFRAMES:", len(elements))
                new_elements=self.get_frame_elements(elements,tags)
                print("LEN OF NEW ELEMENTS IN FRAME", len(new_elements))
                final_elements.extend(new_elements)
                self.relevant_elements=self.classifier.classify_frame(new_elements,self.driver)
        return self.relevant_elements


    def get_frame_elements(self,frames,tags):
        final_elements=[]
        self.driver.switch_to_default_content()
        time.sleep(5)
        for frame in frames:
            print("In Frame", frame.get_attribute("title"))
            try:
                self.driver.switch_to_frame(frame)
                for tag in tags:
                    elements=self.driver.find_elements_by_xpath(tag)
                    for elem in elements:
                        elem= {'element': elem, "iframe": frame}
                        final_elements.append(elem)
            except Exception as e:
                print("FRAME UNAVAILABLE", e)
            self.driver.switch_to_default_content()
        return final_elements

    def map_element(self,element):
        labelled_elements=[elem for elem in self.relevant_elements if elem['label']==element]
        labelled_elements.sort(key=lambda y: y['cosine'], reverse=True)
        return labelled_elements

    def click(self,element,element_label):
        self.previous_element=self.current_element
        self.unsuccessful=True

        web_elements=self.map_element(element_label)
        print(web_elements)

        for web_elem in web_elements:
            web_element=web_elem['element']

            
            if(web_element!=0):
                try:
                    if(web_elem['iframe']!=None):
                        self.driver.switch_to_frame(web_elem['iframe'])
                    web_element.click()
                    self.unsuccessful=False
                    if(element==0): #Add to cart
                        self.items_in_cart+=1
                    if(element==12):
                        self.items_in_cart+=(-1)
                    if(web_elem['iframe']!=None):
                        self.driver.switch_to_default_content()
                    break
                except Exception as e:
                    try:
                        self.driver.execute_script("arguments[0].click()", web_element)
                        self.unsuccessful=False
                        if(element==0):
                            self.items_in_cart+=1
                        if(element==12):
                            self.items_in_cart+=(-1)
                        if(web_elem['iframe']!=None):
                            self.driver.switch_to_default_content()
                        break
                    except Exception as e:
                        print("Unsuccessful")
                        self.unsuccessful=True
                        if(web_elem['iframe']!=None):
                            self.driver.switch_to_default_content()
            else:
                self.unsuccessful=True
            
                time.sleep(10)

        if(self.unsuccessful):
            element=-1

        previous_cookies=self.cookies
        previous_popup=self.popup
        self.get_relevant_elements()
        self.detect_cookies()
        self.detect_popup()

        if(element==-1 or(previous_cookies==1 and self.cookies==0) or (previous_popup==1 and self.popup==0)):
            self.current_element=self.previous_element
        else:
            self.current_element=element


        return element
    
    def send_keys(self,element,input,element_label,enter):
        self.previous_element=self.current_element
        self.unsuccessful=True
        web_elements=self.map_element(element_label)
        print(web_elements)
        for web_elem in web_elements:
            web_element=web_elem['element']
            if(web_element!=0):
                try:
                    if(web_elem['iframe']!=None):
                        self.driver.switch_to_frame(web_elem['iframe'])
                    if(not enter):
                        web_element.send_keys(input)
                    elif (enter):
                        web_element.send_keys(input,Keys.ENTER)
                    if(web_elem['iframe']!=None):
                        self.driver.switch_to_default_content()
                    self.unsuccessful=False
                    
                    break

                except Exception as e:
                    print("KEYS UNSUCCESSFUL", e)
                    self.unsuccessful=True
                    if(web_elem['iframe']!=None):
                        self.driver.switch_to_default_content()
            
        #         time.sleep(10)
        #self.unsuccessful=False
        if(self.unsuccessful):
            element=-1

        previous_cookies=self.cookies
        previous_popup=self.popup
        self.get_relevant_elements()
        self.detect_cookies()
        self.detect_popup()

        if(element==-1 or(previous_cookies==1 and self.cookies==0) or (previous_popup==1 and self.popup==0)):
            self.current_element=self.previous_element
        else:
            self.current_element=element

      
        return element

    def detect_cookies(self):
        web_elements=self.map_element("cookies")
        if(web_elements==[]):
            self.cookies=0
        else:
            self.cookies=1

    def detect_popup(self):
        if(self.url=="https://newegg.com"):
            try:
                popup=self.driver.find_element_by_class_name("adpopup-injected")
                if(popup!=None and popup.is_displayed()):
                    self.popup=1
                else: 
                    self.popup=0
            except Exception as e:
                self.popup=0
    
    def close(self):
        self.driver.close()
        