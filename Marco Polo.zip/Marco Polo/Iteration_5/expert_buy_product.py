
import pickle
from imitation.data import types
import numpy as np

def search():
    acts_abe=[[1,6], [0,0],[0,7]]
    obs_abe=[[-1,0,0,0], [6,0,0,0], [0,1,0,0], [7,1,0,0]]

    traj_abe_books=types.Trajectory(obs_abe,acts_abe,None)

    acts_alibris=[[1,6], [0,0],[0,7]]
    obs_alibris=[[-1,0,0,0], [6,0,0,0], [0,1,0,0], [7,1,0,0]]

    traj_alibris_books=types.Trajectory(obs_alibris,acts_alibris,None)

    acts_amazon=[[1,6],[0,8], [0,0], [0,7]]
    obs_amazon=[[-1,0,0,0],[6,0,0,0], [8,0,0,0], [0,1,0,0], [7,1,0,0]]

    traj_amazon=types.Trajectory(obs_amazon, acts_amazon,None)

    acts_manomano=[[0,15],[1,6],[0,8], [0,0],[0,13], [0,7]]
    obs_manomano=[[-1,0,1,0],[-1,0,0,0],[6,0,0,0], [8,0,0,0], [0,1,0,0],[13,1,0,0], [7,1,0,0]]

    traj_manomano=types.Trajectory(obs_manomano, acts_manomano,None)

    acts_newegg=[[0,16],[1,6],[0,8], [0,0],[0,13], [0,7]]
    obs_newegg=[[-1,0,1,0],[-1,0,0,0],[6,0,0,0], [8,0,0,0], [0,1,0,0],[13,1,0,0], [7,1,0,0]]

    traj_newegg=types.Trajectory(obs_newegg, acts_newegg,None)

    acts_barnesandnoble=[[0,15],[1,6],[0,8], [0,0],[0,13], [0,7]]
    obs_barnesandnoble=[[-1,0,1,0],[-1,0,0,0],[6,0,0,0], [8,0,0,0], [0,1,0,0],[13,1,0,0], [7,1,0,0]]

    traj_barnesandnoble=types.Trajectory(obs_barnesandnoble, acts_barnesandnoble,None)

    return np.array([traj_amazon,traj_alibris_books, traj_newegg, traj_barnesandnoble])

def menu():
    acts_abe=[[0,10], [0,8],[0,0],[0,7]]
    obs_abe=[[-1,0,0,0], [10,0,0,0], [8,0,0,0],[0,1,0,0],[7,1,0,0]]

    traj_abe_books=types.Trajectory(obs_abe,acts_abe,None)


    acts_alibris=[[0,10], [0,11],[0,0],[0,7]]
    obs_alibris=[[-1,0,0,0], [10,0,0,0], [11,0,0,0],[0,1,0,0],[7,1,0,0]]

    traj_alibris=types.Trajectory(obs_alibris,acts_alibris,None)

    acts_amazon=[[0,9],[0,10], [0,11], [0,8], [0,0], [0,7]]
    obs_amazon=[[-1,0,0,0],[9,0,0,0], [10,0,0,0],[11,0,0,0], [8,0,0,0], [0,1,0,0], [7,1,0,0]]

    traj_amazon=types.Trajectory(obs_amazon, acts_amazon,None)


    acts_amazon_2=[[0,9],[0,10], [0,11], [0,8], [0,0], [0,13], [0,7]]
    obs_amazon_2=[[-1,0,0,0],[9,0,0,0], [10,0,0,0],[11,0,0,0], [8,0,0,0], [0,1,0,0], [13,1,0,0], [7,1,0,0]]

    traj_amazon_2=types.Trajectory(obs_amazon_2, acts_amazon_2,None)

    acts_barnesandnoble=[[0,15],[0,10],[0,8], [0,0], [0,13],[0,7]]
    obs_barnesandnoble=[[-1,0,1,0],[-1,0,0,0],[10,0,0,0], [8,0,0,0], [0,1,0,0],[13,1,0,0],[7,0,0,0]]

    traj_barnesandnoble=types.Trajectory(obs_barnesandnoble, acts_barnesandnoble,None)


    acts_newegg=[[0,16],[0,10], [0,11] ,[0,8], [0,0],[0,16], [0,13],[0,16],[0,7]]
    obs_newegg=[[-1,0,1,0],[-1,0,0,0],[10,0,0,0],[11,0,0,0],[8,0,0,0], [0,1,0,1],[0,1,0,0],[13,1,0,1],[13,1,0,0],[7,0,0,0]]

    traj_newegg=types.Trajectory(obs_newegg, acts_newegg,None)


    acts_manomano=[[0,15],[0,9],[0,10],[0,11],[0,11], [0,8], [0,0], [0,13],[0,7]]
    obs_manomano=[[-1,0,1,0],[-1,0,0,0],[9,0,0,0],[10,0,0,0],[11,0,0,0],[11,0,0,0],[8,0,0,0], [0,1,0,0],[13,1,0,0],[7,0,0,0]]

    traj_manomano=types.Trajectory(obs_manomano, acts_manomano,None)

    return np.array([traj_abe_books,traj_alibris,traj_amazon, traj_manomano, traj_newegg])

def card():
    acts_abe=[[0,8],[0,0],[0,7]]
    obs_abe=[[-1,0,0,0], [8,0,0,0],[0,1,0,0],[7,1,0,0]]

    traj_abe_books=types.Trajectory(obs_abe,acts_abe,None)

    acts_alibris=[[0,8],[0,0],[0,7]]
    obs_alibris=[[-1,0,0,0], [8,0,0,0],[0,1,0,0],[7,1,0,0]]

    traj_alibris=types.Trajectory(obs_alibris,acts_alibris,None)

    acts_amazon=[ [0,8], [0,0], [0,7]]
    obs_amazon=[[-1,0,0,0], [8,0,0,0], [0,1,0,0], [7,1,0,0]]

    traj_amazon=types.Trajectory(obs_amazon, acts_amazon,None)

    acts_manomano=[[0,15], [0,8], [0,0], [0,13],[0,7]]
    obs_manomano=[[-1,0,1,0],[-1,0,0,0], [8,0,0,0], [0,1,0,0],[13,1,0,0],[7,0,0,0]]

    traj_manomano=types.Trajectory(obs_manomano, acts_manomano,None)

    acts_barnesandnoble=[[0,15], [0,8], [0,0], [0,13],[0,7]]
    obs_barnesandnoble=[[-1,0,1,0],[-1,0,0,0], [8,0,0,0], [0,1,0,0],[13,1,0,0],[7,0,0,0]]

    traj_barnesandnoble=types.Trajectory(obs_barnesandnoble, acts_barnesandnoble,None)

    acts_newegg=[[0,16], [0,8], [0,0],[0,16], [0,13],[0,16],[0,7]]
    obs_newegg=[[-1,0,1,0],[-1,0,0,0], [8,0,0,0], [0,1,0,1],[0,1,0,0],[13,1,0,1],[13,1,0,0],[7,0,0,0]]

    traj_newegg=types.Trajectory(obs_newegg, acts_newegg,None)

    return np.array([traj_abe_books,traj_alibris,traj_amazon, traj_manomano, traj_newegg])

def main():
    search_traj= search()
    menu_traj= menu()
    card_traj= card()

    arr=np.concatenate((search_traj,menu_traj,card_traj))


    file=open('expert_buy_product_combined.pkl', 'wb')
    pickle.dump(arr, file, pickle.HIGHEST_PROTOCOL)

main()