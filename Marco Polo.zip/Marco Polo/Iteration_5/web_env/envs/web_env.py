import gym
from gym import spaces
import numpy as np
import math
from random import randint
from datetime import datetime


from selenium import webdriver
from selenium.common.exceptions import *
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.support.ui import Select

from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.common.by import By

from web_driver_classes import Generic_site

class Web_Env(gym.Env):
    metadata={'render.modes': ['human']}

    def __init__(self,url):
        super (Web_Env,self).__init__()

        #type_of_action, element_no
        self.action_space=spaces.MultiDiscrete([2,17])

        #element (check_spreadsheet), cart_empty
        self.observation_space=spaces.Box(low=np.array([-1,0,0,0]), high=np.array([16,1,1,1]), shape=(4,), dtype=np.int32)


        self.done=False
        self.actions=[]
        self.observations=[]
        self.web_driver=None
        self.step_no=0
        self.goals=[]

        self.url=url
        #self.url="https://alibris.com"

        self.elements={0: "addtocart", 
        1: "login", 2: "username",
        3: "password", 4: "continue", 5:"account",
        6: "search", 7:"checkout", 8: "productlisting", 9: "menu", 
        10: "menuitem", 11:"submenuitem", 12: "removefromcart", 13: "basket",
        14: "cookies", 15: "allow", 16: "close"}

    def reset(self):
        if(self.actions!=[]):
            self.log_file()
        self.actions=[]
        self.observations=[]

        self.create_web_driver()
        self.goal_id=[0,7]
        self.goals=[0,7]
        self.experiment_name="Iteration 5_Buy_Product_Newegg"

        self.step_no=0
   
        obs=np.array([-1,0,self.web_driver.cookies, self.web_driver.popup])
        self.observations.append(obs)
        self.percentage=0
        return obs

    
    def step(self,action):
        print("STEP:", action)
        obs=self.take_action(action)
        print("OBSERVATION", obs)

        self.actions.append(action)
        self.observations.append(obs)

        reward=0

        self.done=self.is_done()
        print(self.goal_id)
        self.step_no+=1
        self.percentage_done()

        return obs,reward,self.done,{}

    
    def render(self, mode='human', close=False):
        print(f"Step:{self.step_no}")
        print(f"Actions:{self.actions}")
        print(f"Observations:{self.observations}")

    def take_action(self,action):
        print(action)
        action_type=action[0]
        element_id=action[1]

        #CLICK
        if(action_type==0):
            obs= self.click_action(element_id,self.elements.get(element_id))
        elif(action_type==1):
            obs= self.keys_action(element_id,self.elements.get(element_id))
        else:
            print("INVALID ACTION TYPE CHOSEN")

        self.update_goal_id()
        return obs

    def click_action(self,element_id,element_label):
        if(element_id in [0,1,4,5,7,8,9,10,11,12,13,15,16]):
            print("Clicking action")
            self.web_driver.click(element_id,element_label)
        obs=np.array([self.web_driver.current_element,self.web_driver.items_in_cart,self.web_driver.cookies, self.web_driver.popup])

        return obs


    def keys_action(self,element_id,element_label):
        obs=[]
        print("Keys action")
        inp=""
        enter=False
        if(element_id in [2,3,6]):
            if(element_id==2):
                inp="msctestingagent@gmail.com"
            elif(element_id==3):
                inp="TestingAgent21"
            elif(element_id==6 and self.url!="https://newegg.com" and self.url!="https://manomano.co.uk"):
                inp="Software Testing"
                enter=True
            elif(element_id==6 and (self.url=="https://newegg.com" or self.url=="https://manomano.co.uk")):
                inp="Star wars"
                enter=True
            self.web_driver.send_keys(element_id,inp,element_label,enter)

        obs=np.array([self.web_driver.current_element,self.web_driver.items_in_cart,self.web_driver.cookies, self.web_driver.popup])
        return obs


    def create_web_driver(self):
        if(self.web_driver==None):
            self.web_driver=Generic_site.Drv(self.url)

        self.web_driver.reset()

    def close(self):
        self.web_driver.close()
    

    def is_done(self):
        done=True
        for id in self.goal_id:
            if(id!=-2):
                done=False
                break
        return done

    def percentage_done(self):
        no_of_goals=len(self.goal_id)
        no_of_goals_done= self.goal_id.count(-2)
        percentage= (no_of_goals_done/no_of_goals)*100 
        self.percentage=percentage
        print(percentage)
    
    def update_goal_id(self):
        if(self.web_driver.current_element==-1):
            return
        else: 
            if self.web_driver.current_element in self.goal_id:
                index=self.goal_id.index(self.web_driver.current_element)
                if(index==0):
                    self.goal_id[index]=-2
                elif(self.goal_id[index-1]==-2):
                    self.goal_id[index]=-2
            else:
                return
    
    def log_file(self):
        time= datetime.now().strftime("%m/%d/%Y, %H:%M:%S")
        url= "URL:"+ self.url
        goals="Goals:"+ str(self.goals)
        percentage="Percentage: "+ str(self.percentage)
        obs="Observations:"+ str(self.observations)
        act="Actions: "+ str(self.actions)
        steps="Steps: "+ str(self.step_no)

        content= time+ "\n"+ url+ "\n" + goals + "\n" + percentage + "\n" + obs + "\n" + act + "\n" + steps + "\n ---------------------------\n"

        f= open(self.experiment_name+".txt", 'a')
        f.write(content)
        f.close()




