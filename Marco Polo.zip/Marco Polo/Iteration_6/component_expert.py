import pickle
from imitation.data import types
import numpy as np


def go_to_account():

    actions = [[0,5]]
    obs = [[-1,0,0,0,0],[5,0,0,0,0]]

    traj_from_home =types.Trajectory(obs,actions, None)

    actions = [[0,5]]
    obs=[[-1,1,0,0,0], [5,1,0,0,0]]
    traj_from_home_item_in_cart=types.Trajectory(obs,actions,None)

    actions=[[0,5]]
    obs=[[-1,1,0,0,1], [5,1,0,0,1]]
    traj_from_home_item_in_cart_logged=types.Trajectory(obs,actions,None)

    actions=[[0,5]]
    obs=[[-1,0,0,0,1], [5,0,0,0,1]]
    traj_from_home_logged=types.Trajectory(obs,actions,None)

    return np.array([traj_from_home,
                     traj_from_home_item_in_cart,
                     traj_from_home_item_in_cart_logged,
                     traj_from_home_logged])

def login():

    actions=[[0,1],[1,2],[1,3], [0,1]]
    obs=[[-1,0,0,0,0], [1,0,0,0,0], [2,0,0,0,0],[3,0,0,0,0], [1,0,0,0,1]]

    traj_from_home= types.Trajectory(obs,actions,None)

    actions=[[0,1],[1,2],[1,3], [0,1]]
    obs=[[-1,1,0,0,0], [1,1,0,0,0], [2,1,0,0,0],[3,1,0,0,0], [1,1,0,0,1]]

    traj_from_home_item_in_cart= types.Trajectory(obs,actions,None)

    actions=[[0,1],[1,2],[1,3],[0,1]]
    obs=[[5,0,0,0,0], [1,0,0,0,0], [2,0,0,0,0], [3,0,0,0,0], [1,0,0,0,1]]

    traj_from_account = types.Trajectory(obs,actions,None)

    actions=[[0,1],[1,2],[1,3],[0,1]]
    obs=[[5,1,0,0,0], [1,1,0,0,0], [2,1,0,0,0], [3,1,0,0,0], [1,1,0,0,1]]

    traj_from_account_item_in_cart=types.Trajectory(obs,actions,None)

    actions=[[1,2],[1,3],[0,1]]
    obs=[[7,1,0,0,0], [2,1,0,0,0], [3,1,0,0,0], [1,1,0,0,1]]

    traj_checkout=types.Trajectory(obs,actions,None)

    return np.array([traj_from_home,
                     traj_from_home_item_in_cart,
                     traj_from_account_item_in_cart,
                     traj_from_account,
                     traj_checkout])


def search():
    actions= [[0,6]]
    obs=[[-1,0,0,0,0], [6,0,0,0,0]]

    traj_from_home=types.Trajectory(obs,actions,None)

    actions=[[1,6]]
    obs=[[-1,1,0,0,0], [6,1,0,0,0]]

    traj_from_home_item_in_cart=types.Trajectory(obs,actions,None)

    actions=[[1,6]]
    obs=[[-1,0,0,0,1],[6,0,0,0,1]]
    traj_from_home_search = types.Trajectory(obs,actions,None)

    actions=[[1,6]]
    obs=[[-1,1,0,0,1], [6,1,0,0,1]]
    traj_from_home_everything= types.Trajectory(obs,actions,None)

    actions=[[1,6]]
    obs=[[0,1,0,0,0], [6,1,0,0,0]]

    traj_from_cart= types.Trajectory(obs,actions,None)

    actions=[[1,6]]
    obs=[[0,1,0,0,1], [6,1,0,0,1]]
    traj_from_cart_login = types.Trajectory(obs,actions,None)

    actions=[[1,6]]
    obs=[[13,1,0,0,0], [6,1,0,0,0]]

    traj_from_basket=types.Trajectory(obs,actions,None)

    actions=[[1,6]]
    obs=[[13,1,0,0,1], [6,1,0,0,1]]
    traj_from_basket_login= types.Trajectory(obs,actions,None)

    actions=[[1,6]]
    obs=[[12,0,0,0,0], [6,0,0,0,0]]
    traj_from_remove_from_cart=types.Trajectory(obs,actions,None)

    actions=[[1,6]]
    obs=[[12,0,0,0,1],[6,0,0,0,1]]
    traj_from_remove_from_cart_login= types.Trajectory(obs,actions,None)



    actions=[[1,6]]
    obs=[[5,0,0,0,1], [6,0,0,0,1]]
    traj_from_account_login = types.Trajectory(obs,actions,None)

    actions=[[1,6]]
    obs=[[5,1,0,0,1], [6,1,0,0,1]]
    traj_from_account_everything= types.Trajectory(obs,actions,None)


    actions=[[1,6]]
    obs=[[1,0,0,0,1], [6,0,0,0,1]]
    traj_from_login= types.Trajectory(obs,actions,None)

    actions=[[1,6]]
    obs=[[-1,1,0,0,1], [6,1,0,0,1]]
    traj_everything=types.Trajectory(obs,actions,None)

    return np.array([traj_from_home,
                    traj_from_home_item_in_cart,
                    traj_from_home_search,
                    traj_from_home_everything,
                    traj_from_cart,
                    traj_from_cart_login,
                    traj_from_basket,
                    traj_from_basket_login,
                    traj_from_remove_from_cart,
                    traj_from_remove_from_cart_login,
                    traj_from_account_login,
                    traj_from_account_everything,
                    traj_from_login,
                    traj_everything])

def add_to_cart():
    actions=[[0,0]]
    obs=[[8,0,0,0,0], [0,1,0,0,0]]
    traj_product_card=types.Trajectory(obs,actions,None)

    actions=[[0,0]]
    obs=[[8,1,0,0,0], [0,1,0,0,0]]
    traj_item_in_cart=types.Trajectory(obs,actions,None)

    actions=[[0,0]]
    obs=[[8,0,0,0,1], [0,1,0,0,1]]
    traj_login=types.Trajectory(obs,actions,None)

    actions=[[0,0]]
    obs=[[8,1,0,0,1], [0,1,0,0,1]]
    traj_everything= types.Trajectory(obs,actions,None)

    return np.array([traj_product_card, 
                     traj_item_in_cart, 
                     traj_everything, 
                     traj_login])

def select_item():
    actions=[[0,8]]
    obs=[[6,0,0,0,0], [8,0,0,0,0]]
    traj_search=types.Trajectory(obs,actions,None)

    actions=[[0,8]]
    obs=[[6,1,0,0,0], [8,1,0,0,0]]
    traj_search_item_in_cart=types.Trajectory(obs,actions,None)

    actions=[[0,8]]
    obs=[[6,0,0,0,1], [8,0,0,0,1]]
    traj_search_login= types.Trajectory(obs,actions,None)

    actions=[[0,8]]
    obs=[[6,1,0,0,1], [8,1,0,0,1]]
    traj_search_everything=types.Trajectory(obs,actions,None)

    actions=[[0,8]]
    obs=[[-1,0,0,0,0], [8,0,0,0,0]]
    traj_from_home=types.Trajectory(obs,actions,None)

    actions=[[0,8]]
    obs=[[-1,1,0,0,0], [8,1,0,0,0]]
    traj_from_home_item_in_cart= types.Trajectory(obs,actions,None)

    actions=[[0,8]]
    obs=[[-1,0,0,0,1], [8,0,0,0,1]]
    traj_from_home_login= types.Trajectory(obs,actions,None)

    actions=[[0,8]]
    obs=[[-1,1,0,0,1], [8,1,0,0,1]]
    traj_from_home_everything=types.Trajectory(obs,actions,None)

    actions=[[0,8]]
    obs=[[10,0,0,0,0], [8,0,0,0,0]]
    traj_from_menu= types.Trajectory(obs,actions,None)

    actions=[[0,8]]
    obs=[[10,1,0,0,0], [8,1,0,0,0]]
    traj_from_menu_item_in_cart= types.Trajectory(obs,actions,None)

    actions=[[0,8]]
    obs=[[10,0,0,0,1], [8,0,0,0,1]]
    traj_from_menu_login= types.Trajectory(obs,actions,None)

    actions=[[0,8]]
    obs=[[10,1,0,0,1], [8,1,0,0,1]]
    traj_from_menu_everything=types.Trajectory(obs,actions,None)

    actions=[[0,8]]
    obs=[[11,0,0,0,0], [8,0,0,0,0]]
    traj_from_sub_menu=types.Trajectory(obs,actions,None)

    actions=[[0,8]]
    obs=[[11,1,0,0,0], [8,1,0,0,0]]
    traj_from_sub_menu_cart= types.Trajectory(obs,actions,None)

    actions=[[0,8]]
    obs=[[11,0,0,0,1], [8,0,0,0,1]]
    traj_from_sub_menu_login= types.Trajectory(obs,actions,None)

    actions=[[0,8]]
    obs=[[11,1,0,0,1], [8,1,0,0,1]]
    traj_from_sub_menu_everything= types.Trajectory(obs,actions,None)
    

    return np.array([traj_search,
                    traj_search_item_in_cart,
                    traj_search_login,
                    traj_search_everything,
                    traj_from_home,
                    traj_from_home_login,
                    traj_from_home_everything,
                    traj_from_menu,
                    traj_from_menu_item_in_cart,
                    traj_from_menu_login,
                    traj_from_menu_everything,
                    traj_from_sub_menu,
                    traj_from_sub_menu_cart,
                    traj_from_sub_menu_everything,
                    traj_from_sub_menu_login]) 

def basket():
    actions=[[0,13]]
    obs=[[-1,1,0,0,0], [13,1,0,0,0]]
    traj_from_home_item_in_cart=types.Trajectory(obs,actions,None)

    actions=[[0,13]]
    obs=[[-1,1,0,0,1], [13,1,0,0,1]]
    traj_from_home_everything=types.Trajectory(obs,actions,None)

    actions=[[0,13]]
    obs=[[0,1,0,0,0], [13,1,0,0,0]]
    traj_from_item=types.Trajectory(obs,actions,None)

    actions=[[0,13]]
    obs=[[0,1,0,0,1], [13,1,0,0,1]]
    traj_from_item_everything= types.Trajectory(obs,actions,None)

    return np.array([traj_from_home_item_in_cart, 
                     traj_from_home_everything, 
                     traj_from_item, 
                     traj_from_item_everything])

def checkout():
    actions=[[0,7]]
    obs=[[0,1,0,0,0], [7,1,0,0,0]]

    traj_checkout= types.Trajectory(obs,actions,None)

    actions= [[0,7]]
    obs= [[0,1,0,0,1], [7,1,0,0,1]]

    traj_checkout_login= types.Trajectory(obs,actions,None)

    actions=[[0,7]]
    obs=[[13,1,0,0,0], [7,1,0,0,0]]

    traj_basket= types.Trajectory(obs,actions,None)

    actions=[[0,7]]
    obs=[[13,1,0,0,1], [7,1,0,0,1]]

    traj_basket_login= types.Trajectory(obs,actions,None)

    return np.array([traj_checkout,
                     traj_checkout_login, 
                     traj_basket, 
                     traj_basket_login])

def remove_from_cart():
    actions=[[0,12]]
    obs=[[13,1,0,0,0],[12,0,0,0,0]]

    traj_basket=types.Trajectory(obs,actions,None)

    actions=[[0,12]]
    obs=[[0,1,0,0,0], [12,0,0,0,0]]

    traj_add_to_cart=types.Trajectory(obs,actions,None)

    actions=[[0,12]]
    obs=[[13,1,0,0,1], [12,0,0,0,1]]

    traj_basket_login= types.Trajectory(obs,actions,None)

    actions=[[0,12]]
    obs=[[0,1,0,0,1], [12,0,0,0,1]]

    traj_everything= types.Trajectory(obs,actions,None)

    actions=[[0,12]]
    obs=[[0,1,0,0,0], [12,1,0,0,0]]
    traj_basket_after_remove= types.Trajectory(obs,actions,None)

    actions=[[0,12]]
    ob=[[0,1,0,0,1], [12,1,0,0,1]]
    traj_basket_after_remove_login = types.Trajectory(obs,actions,None)


    return np.array([traj_basket, 
                     traj_add_to_cart, 
                     traj_basket_login, 
                     traj_everything,
                     traj_basket_after_remove,
                     traj_basket_after_remove_login])


def go_home():
    actions=[[2,17]]
    obs=[[7,1,0,0,0], [-1,1,0,0,0]]

    traj_checkout= types.Trajectory(obs,actions,None)

    actions=[[2,17]]
    obs=[[7,1,0,0,1], [-1,1,0,0,1]]

    traj_checkout_login= types.Trajectory(obs,actions,None)

    actions=[[2,17]]
    obs=[[1,0,0,0,1], [-1,0,0,0,1]]

    traj_login= types.Trajectory(obs,actions,None)

    actions=[[2,17]]
    obs=[[1,1,0,0,1], [-1,1,0,0,1]]

    traj_login_item= types.Trajectory(obs,actions,None)

    actions=[[2,17]]
    obs=[[12,0,0,0,0],[-1,0,0,0,0]]

    traj_remove= types.Trajectory(obs,actions,None)

    actions=[[2,17]]
    obs=[[12,0,0,0,1], [-1,0,0,0,1]]
    traj_remove_login= types.Trajectory(obs,actions,None)

    actions=[[2,17]]
    obs=[[12,1,0,0,1], [-1,1,0,0,1]]
    traj_remove_item_login= types.Trajectory(obs,actions,None)

    actions=[[2,17]]
    obs==[[12,1,0,0,0], [-1,1,0,0,0]]
    traj_remove_item=types.Trajectory(obs,actions,None)

    actions=[[2,17]]
    obs=[[13,1,0,0,0], [-1,1,0,0,0]]

    traj_basket=types.Trajectory(obs,actions,None)

    actions=[[2,17]]
    obs=[[13,1,0,0,1], [-1,1,0,0,1]]
    
    traj_basket_login= types.Trajectory(obs,actions,None)

    actions=[[2,17]]
    obs=[[1,1,0,0,0], [-1,1,0,0,1]]
    traj_login_checkout= types.Trajectory(obs,actions,None)



    return np.array([traj_checkout, 
                     traj_checkout_login, 
                     traj_login, 
                     traj_login_item, 
                     traj_remove,
                     traj_remove_login,
                     traj_basket, 
                     traj_basket_login,
                     traj_remove_item,
                     traj_remove_item_login,
                     traj_login,
                     traj_login_checkout])

def cookies():
    actions=[[0,15]]
    obs=[[-1,0,1,0,0], [-1,0,0,0,0]]

    traj_close=types.Trajectory(obs,actions,None)


    actions=[[0,16]]
    obs=[[-1,0,1,0,0], [-1,0,0,0,0]]

    traj_accept = types.Trajectory(obs,actions,None)

    return np.array([traj_close, traj_accept])

def menu():

    # actions=[[0,10]]
    # obs=[[0,1,0,0,0], [10,1,0,0,0]]
    # traj_menu_add_to_cart=types.Trajectory(obs,actions,None)

    # actions=[[0,10]]
    # obs=[[0,1,0,0,1], [10,1,0,0,1]]
    # traj_menu_add_to_cart_login =types.Trajectory(obs,actions,None)

    # actions=[[0,10]]
    # obs=[[13,1,0,0,1], [10,1,0,0,1]]
    # traj_basket_login= types.Trajectory(obs,actions,None)

    # actions=[[0,10]]
    # obs=[[13,1,0,0,0], [10,1,0,0,0]]
    # traj_basket_item= types.Trajectory(obs,actions,None)

    # actions=[[0,10]]
    # obs=[[12,0,0,0,0], [10,0,0,0,0]]
    # traj_remove_from_cart=types.Trajectory(obs,actions,None)

    # actions=[[0,10]]
    # obs=[[12,0,0,0,1], [10,0,0,0,1]]
    # traj_remove_from_cart_login= types.Trajectory(obs,actions,None)

    # actions=[[0,10]]
    # obs=[[12,1,0,0,1], [10,1,0,0,1]]
    # traj_remove_item_login= types.Trajectory(obs,actions,None)

    # actions=[[0,10]]
    # obs=[[12,1,0,0,0], [10,1,0,0,0]]
    # traj_remove_item=types.Trajectory(obs,actions,None)


    # actions=[[0,9], [0,10]]
    # obs=[[0,1,0,0,0], [9,1,0,0,0], [10,1,0,0,0]]
    # traj_header_menu_add_to_cart= types.Trajectory(obs,actions,None)

    # actions=[[0,9], [0,10]]
    # obs=[[0,1,0,0,1], [9,1,0,0,1], [10,1,0,0,1]]
    # traj_header_menu_login= types.Trajectory(obs,actions,None)

    # actions=[[0,9],[0,10]]
    # obs=[[13,1,0,0,0], [9,1,0,0,0], [10,1,0,0,0]]
    # traj_header_menu_basket=types.Trajectory(obs,actions,None)

    # actions=[[0,9], [0,10]]
    # obs=[[13,1,0,0,1], [9,1,0,0,1], [10,1,0,0,1]]
    # traj_header_menu_basket_login= types.Trajectory(obs,actions,None)

    # actions=[[0,9], [0,10]]
    # obs=[[12,0,0,0,0], [9,0,0,0,0], [10,0,0,0,0]]
    # traj_header_menu_remove= types.Trajectory(obs,actions,None)

    # actions=[[0,9], [0,10]]
    # obs=[[12,0,0,0,1], [9,0,0,0,1], [10,0,0,0,1]]
    # traj_header_remove_login= types.Trajectory(obs,actions,None)

    # actions=[[0,9], [0,10],[0,11]]
    # obs=[[0,1,0,0,0], [9,1,0,0,0], [10,1,0,0,0],[11,1,0,0,0]]
    # traj_sub_menu_add_to_cart= types.Trajectory(obs,actions,None)

    # actions=[[0,9], [0,10],[0,11]]
    # obs=[[0,1,0,0,1], [9,1,0,0,1], [10,1,0,0,1],[11,1,0,0,1]]
    # traj_sub_menu_login= types.Trajectory(obs,actions,None)

    # actions=[[0,9],[0,10],[0,11]]
    # obs=[[13,1,0,0,0], [9,1,0,0,0], [10,1,0,0,0],[11,1,0,0,0]]
    # traj_sub_menu_basket=types.Trajectory(obs,actions,None)

    # actions=[[0,9], [0,10],[0,11]]
    # obs=[[13,1,0,0,1], [9,1,0,0,1], [10,1,0,0,1], [11,1,0,0,1]]
    # traj_sub_menu_basket_login= types.Trajectory(obs,actions,None)

    # actions=[[0,9], [0,10],[0,11]]
    # obs=[[12,0,0,0,0], [9,0,0,0,0], [10,0,0,0,0],[11,0,0,0,0]]
    # traj_sub_menu_remove= types.Trajectory(obs,actions,None)

    # actions=[[0,9], [0,10],[0,11]]
    # obs=[[12,0,0,0,1], [9,0,0,0,1], [10,0,0,0,1],[11,0,0,0,1]]
    # traj_sub_menu_remove_login= types.Trajectory(obs,actions,None)


    # actions=[[0,10]]
    # obs=[[-1,0,0,0,0],[10,0,0,0,0]]

    # traj_menu= types.Trajectory(obs,actions,None)

    # actions=[[0,10]]
    # obs=[[-1,1,0,0,0], [10,1,0,0,0]]
    # traj_menu_item= types.Trajectory(obs,actions,None)

    # actions=[[0,10]]
    # obs=[[-1,1,0,0,1], [10,1,0,0,1]]
    
    # traj_menu_everything= types.Trajectory(obs,actions,None)

    # actions=[[0,10]]
    # obs=[[-1,0,0,0,1], [10,0,0,0,1]]

    # traj_menu_login= types.Trajectory(obs,actions,None)

    # actions=[[0,10], [0,11]]
    # obs=[[-1,0,0,0,0], [10,0,0,0,0], [11,0,0,0,0]]

    # traj_submenu=types.Trajectory(obs,actions,None)

    # actions=[[0,10], [0,11]]
    # obs=[[-1,1,0,0,0], [10,1,0,0,0], [11,1,0,0,0]]

    # traj_submenu_item=types.Trajectory(obs,actions,None)


    # actions=[[0,10], [0,11]]
    # obs=[[-1,0,0,0,1], [10,0,0,0,1], [11,0,0,0,1]]

    # traj_submenu_login=types.Trajectory(obs,actions,None)


    # actions=[[0,10], [0,11]]
    # obs=[[-1,1,0,0,1], [10,1,0,0,1], [11,1,0,0,1]]

    # traj_submenu_everything=types.Trajectory(obs,actions,None)
    
    # actions=[[0,9],[0,10],[0,11]]
    # obs=[[-1,0,0,0,0], [9,0,0,0,0], [10,0,0,0,0], [11,0,0,0,0]]
    
    # traj_menu_icon= types.Trajectory(obs,actions,None)


    # actions=[[0,9],[0,10],[0,11]]
    # obs=[[-1,1,0,0,0], [9,1,0,0,0], [10,1,0,0,0], [11,1,0,0,0]]
    
    # traj_menu_icon_item= types.Trajectory(obs,actions,None)


    # actions=[[0,9],[0,10],[0,11]]
    # obs=[[-1,0,0,0,1], [9,0,0,0,1], [10,0,0,0,1], [11,0,0,0,1]]
    
    # traj_menu_icon_login= types.Trajectory(obs,actions,None)


    # actions=[[0,9],[0,10],[0,11]]
    # obs=[[-1,1,0,0,1], [9,1,0,0,1], [10,1,0,0,1], [11,1,0,0,1]]
    
    # traj_menu_icon_everything= types.Trajectory(obs,actions,None)


    # actions=[[0,9],[0,10],[0,11],[0,11]]
    # obs=[[-1,0,0,0,0], [9,0,0,0,0], [10,0,0,0,0], [11,0,0,0,0], [11,0,0,0,0]]

    # traj_submenus= types.Trajectory(obs,actions,None)

    # actions=[[0,9],[0,10],[0,11],[0,11]]
    # obs=[[-1,1,0,0,0], [9,1,0,0,0], [10,1,0,0,0], [11,1,0,0,0], [11,1,0,0,0]]

    # traj_submenus_item= types.Trajectory(obs,actions,None)


    # actions=[[0,9],[0,10],[0,11],[0,11]]
    # obs=[[-1,0,0,0,1], [9,0,0,0,1], [10,0,0,0,1], [11,0,0,0,1], [11,0,0,0,1]]

    # traj_submenus_login= types.Trajectory(obs,actions,None)

    
    # actions=[[0,9],[0,10],[0,11],[0,11]]
    # obs=[[-1,1,0,0,1], [9,1,0,0,1], [10,1,0,0,1], [11,1,0,0,1], [11,1,0,0,1]]

    # traj_submenus_everything= types.Trajectory(obs,actions,None)

    actions=[[0,10]]
    obs=[[0,1,0,0,0], [10,1,0,0,0]]
    traj_menu_add_to_cart=types.Trajectory(obs,actions,None)

    actions=[[0,10]]
    obs=[[0,1,0,0,1], [10,1,0,0,1]]
    traj_menu_add_to_cart_login =types.Trajectory(obs,actions,None)

    actions=[[0,10]]
    obs=[[13,1,0,0,1], [10,1,0,0,1]]
    traj_basket_login= types.Trajectory(obs,actions,None)

    actions=[[0,10]]
    obs=[[13,1,0,0,0], [10,1,0,0,0]]
    traj_basket_item= types.Trajectory(obs,actions,None)

    actions=[[0,10]]
    obs=[[12,0,0,0,0], [10,0,0,0,0]]
    traj_remove_from_cart=types.Trajectory(obs,actions,None)

    actions=[[0,10]]
    obs=[[12,0,0,0,1], [10,0,0,0,1]]
    traj_remove_from_cart_login= types.Trajectory(obs,actions,None)

    actions=[[0,10]]
    obs=[[12,1,0,0,1], [10,1,0,0,1]]
    traj_remove_item_login= types.Trajectory(obs,actions,None)

    actions=[[0,10]]
    obs=[[12,1,0,0,0], [10,1,0,0,0]]
    traj_remove_item=types.Trajectory(obs,actions,None)


    actions=[[0,9]]
    obs=[[0,1,0,0,0], [9,1,0,0,0]]
    traj_header_menu_add_to_cart= types.Trajectory(obs,actions,None)

    actions=[[0,9], [0,10]]
    obs=[[0,1,0,0,1], [9,1,0,0,1], [10,1,0,0,1]]
    traj_header_menu_login= types.Trajectory(obs,actions,None)

    actions=[[0,9]]
    obs=[[13,1,0,0,0], [9,1,0,0,0]]
    traj_header_menu_basket=types.Trajectory(obs,actions,None)

    actions=[[0,9]]
    obs=[[13,1,0,0,1], [9,1,0,0,1]]
    traj_header_menu_basket_login= types.Trajectory(obs,actions,None)

    actions=[[0,9], [0,10]]
    obs=[[12,0,0,0,0], [9,0,0,0,0], [10,0,0,0,0]]
    traj_header_menu_remove= types.Trajectory(obs,actions,None)

    actions=[[0,9]]
    obs=[[12,0,0,0,1], [9,0,0,0,1]]
    traj_header_remove_login= types.Trajectory(obs,actions,None)

    actions=[[0,9]]
    obs=[[0,1,0,0,0], [9,1,0,0,0]]
    traj_sub_menu_add_to_cart= types.Trajectory(obs,actions,None)

    actions=[[0,9]]
    obs=[[0,1,0,0,1], [9,1,0,0,1]]
    traj_sub_menu_login= types.Trajectory(obs,actions,None)

    actions=[[0,9]]
    obs=[[13,1,0,0,0], [9,1,0,0,0]]
    traj_sub_menu_basket=types.Trajectory(obs,actions,None)

    actions=[[0,9]]
    obs=[[13,1,0,0,1], [9,1,0,0,1]]
    traj_sub_menu_basket_login= types.Trajectory(obs,actions,None)

    actions=[[0,9]]
    obs=[[12,0,0,0,0], [9,0,0,0,0]]
    traj_sub_menu_remove= types.Trajectory(obs,actions,None)

    actions=[[0,9]]
    obs=[[12,0,0,0,1], [9,0,0,0,1]]
    traj_sub_menu_remove_login= types.Trajectory(obs,actions,None)


    actions=[[0,10]]
    obs=[[-1,0,0,0,0],[10,0,0,0,0]]

    traj_menu= types.Trajectory(obs,actions,None)

    actions=[[0,10]]
    obs=[[-1,1,0,0,0], [10,1,0,0,0]]
    traj_menu_item= types.Trajectory(obs,actions,None)

    actions=[[0,10]]
    obs=[[-1,1,0,0,1], [10,1,0,0,1]]
    
    traj_menu_everything= types.Trajectory(obs,actions,None)

    actions=[[0,10]]
    obs=[[-1,0,0,0,1], [10,0,0,0,1]]

    traj_menu_login= types.Trajectory(obs,actions,None)

    actions=[[0,10], [0,11]]
    obs=[[-1,0,0,0,0], [10,0,0,0,0], [11,0,0,0,0]]

    traj_submenu=types.Trajectory(obs,actions,None)

    actions=[[0,10], [0,11]]
    obs=[[-1,1,0,0,0], [10,1,0,0,0], [11,1,0,0,0]]

    traj_submenu_item=types.Trajectory(obs,actions,None)


    actions=[[0,10], [0,11]]
    obs=[[-1,0,0,0,1], [10,0,0,0,1], [11,0,0,0,1]]

    traj_submenu_login=types.Trajectory(obs,actions,None)


    actions=[[0,10], [0,11]]
    obs=[[-1,1,0,0,1], [10,1,0,0,1], [11,1,0,0,1]]

    traj_submenu_everything=types.Trajectory(obs,actions,None)
    
    actions=[[0,10],[0,11]]
    obs=[ [9,0,0,0,0], [10,0,0,0,0], [11,0,0,0,0]]
    
    traj_menu_icon= types.Trajectory(obs,actions,None)


    actions=[[0,10],[0,11]]
    obs=[ [9,1,0,0,0], [10,1,0,0,0], [11,1,0,0,0]]
    
    traj_menu_icon_item= types.Trajectory(obs,actions,None)


    actions=[[0,10],[0,11]]
    obs=[[9,0,0,0,1], [10,0,0,0,1], [11,0,0,0,1]]
    
    traj_menu_icon_login= types.Trajectory(obs,actions,None)


    actions=[[0,10],[0,11]]
    obs=[[9,1,0,0,1], [10,1,0,0,1], [11,1,0,0,1]]
    
    traj_menu_icon_everything= types.Trajectory(obs,actions,None)


    actions=[[0,11],[0,11]]
    obs=[[10,0,0,0,0], [11,0,0,0,0], [11,0,0,0,0]]

    traj_submenus= types.Trajectory(obs,actions,None)

    actions=[[0,11],[0,11]]
    obs=[[10,1,0,0,0], [11,1,0,0,0], [11,1,0,0,0]]

    traj_submenus_item= types.Trajectory(obs,actions,None)


    actions=[[0,11],[0,11]]
    obs=[[10,0,0,0,1], [11,0,0,0,1], [11,0,0,0,1]]

    traj_submenus_login= types.Trajectory(obs,actions,None)

    
    actions=[[0,11],[0,11]]
    obs=[[10,1,0,0,1], [11,1,0,0,1], [11,1,0,0,1]]

    traj_submenus_everything= types.Trajectory(obs,actions,None)

    return np.array([traj_menu,
            traj_menu_item,
            traj_menu_everything,
            traj_menu_login,
            traj_submenu,
            traj_submenu_item,
            traj_submenu_everything,
            traj_submenu_login,
            traj_menu_icon,
            traj_menu_icon_item,
            traj_menu_icon_login,
            traj_menu_icon_everything,
            traj_submenus,
            traj_submenus_item,
            traj_submenus_login,
            traj_submenu_everything,
            traj_menu_add_to_cart,
            traj_menu_add_to_cart_login,
            traj_basket_login,
            traj_basket_item,
            traj_remove_from_cart,
            traj_remove_from_cart_login,
            traj_header_menu_add_to_cart,
            traj_header_menu_login,
            traj_header_menu_basket,
            traj_header_menu_basket_login,
            traj_header_menu_remove,
            traj_header_remove_login,
            traj_sub_menu_add_to_cart,
            traj_sub_menu_login,
            traj_sub_menu_basket_login,
            traj_sub_menu_remove,
            traj_sub_menu_remove_login,
            traj_remove_item_login,
            traj_remove_item
            ])
            
def main():
    account=go_to_account()
    loggin=login()
    searched= search()
    menued=menu()
    added_to_cart=add_to_cart()
    baskets=basket()
    remove= remove_from_cart()
    item=select_item()
    home= go_home()
    cookie=cookies()
    checkedout=checkout()



    arr=np.concatenate([account,loggin,searched,menued,added_to_cart,baskets,remove,item,home,cookie,checkedout])

    file=open('component_expert.pkl', 'wb')
    pickle.dump(arr, file, pickle.HIGHEST_PROTOCOL)

main()


