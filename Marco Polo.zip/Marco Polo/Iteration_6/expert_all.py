import pickle
from imitation.data import types
import numpy as np

def search():
    acts_abe=[[1,6], [0,0],[0,7],[2,17]]
    obs_abe=[[-1,0,0,0,0], [6,0,0,0,0], [0,1,0,0,0], [7,1,0,0,0],[-1,1,0,0,0]]

    traj_abe_books=types.Trajectory(obs_abe,acts_abe,None)
    
    acts_abe_2=[[1,6], [0,0],[0,7],[2,17]]
    obs_abe_2=[[-1,1,0,0,0], [6,1,0,0,0], [0,1,0,0,0], [7,1,0,0,0],[-1,1,0,0,0]]

    traj_abe_books_2=types.Trajectory(obs_abe_2,acts_abe_2,None)

    acts_abe=[[1,6], [0,0],[0,7],[2,17]]
    obs_abe=[[-1,0,0,0,1], [6,0,0,0,1], [0,1,0,0,1], [7,1,0,0,1],[-1,1,0,0,1]]

    traj_abe_books_3=types.Trajectory(obs_abe,acts_abe,None)
    
    acts_abe_2=[[1,6], [0,0],[0,7],[2,17]]
    obs_abe_2=[[-1,1,0,0,1], [6,1,0,0,1], [0,1,0,0,1], [7,1,0,0,1],[-1,1,0,0,1]]

    traj_abe_books_4=types.Trajectory(obs_abe_2,acts_abe_2,None)

    #---------------------------------------------------------------------------------#

    acts_alibris=[[1,6], [0,0],[0,7],[2,17]]
    obs_alibris=[[-1,0,0,0,0], [6,0,0,0,0], [0,1,0,0,0], [7,1,0,0,0],[-1,1,0,0,0]]


    traj_alibris_books=types.Trajectory(obs_alibris,acts_alibris,None)
    
    acts_alibris_2=[[1,6], [0,0],[0,7],[2,17]]
    obs_alibris_2=[[-1,1,0,0,0], [6,1,0,0,0], [0,1,0,0,0], [7,1,0,0,0],[-1,1,0,0,0]]

    traj_alibris_books_2=types.Trajectory(obs_alibris_2,acts_alibris_2,None)

    acts_alibris=[[1,6], [0,0],[0,7],[2,17]]
    obs_alibris=[[-1,0,0,0,1], [6,0,0,0,1], [0,1,0,0,1], [7,1,0,0,1],[-1,1,0,0,1]]


    traj_alibris_books_3=types.Trajectory(obs_alibris,acts_alibris,None)
    
    acts_alibris_2=[[1,6], [0,0],[0,7],[2,17]]
    obs_alibris_2=[[-1,1,0,0,1], [6,1,0,0,1], [0,1,0,0,1], [7,1,0,0,1],[-1,1,0,0,1]]

    traj_alibris_books_4=types.Trajectory(obs_alibris_2,acts_alibris_2,None)

    #-----------------------------------------------------------------------------------#

    acts_amazon=[[1,6],[0,8], [0,0], [0,7],[2,17]]
    obs_amazon=[[-1,0,0,0,0],[6,0,0,0,0], [8,0,0,0,0], [0,1,0,0,0], [7,1,0,0,0],[-1,1,0,0,0]]

    traj_amazon=types.Trajectory(obs_amazon, acts_amazon,None)
    
    acts_amazon_2=[[1,6],[0,8], [0,0], [0,7],[2,17]]
    obs_amazon_2=[[-1,1,0,0,0],[6,1,0,0,0], [8,1,0,0,0], [0,1,0,0,0], [7,1,0,0,0],[-1,1,0,0,0]]

    traj_amazon_2=types.Trajectory(obs_amazon_2, acts_amazon_2,None)
    
    acts_amazon=[[1,6],[0,8], [0,0], [0,7],[2,17]]
    obs_amazon=[[-1,0,0,0,1],[6,0,0,0,1], [8,0,0,0,1], [0,1,0,0,1], [7,1,0,0,1],[-1,1,0,0,1]]

    traj_amazon_3=types.Trajectory(obs_amazon, acts_amazon,None)
    
    acts_amazon_2=[[1,6],[0,8], [0,0], [0,7],[2,17]]
    obs_amazon_2=[[-1,1,0,0,1],[6,1,0,0,1], [8,1,0,0,1], [0,1,0,0,1], [7,1,0,0,1],[-1,1,0,0,1]]

    traj_amazon_4=types.Trajectory(obs_amazon_2, acts_amazon_2,None)


    #----------------------------------------------------------------------------------_@
    
    acts_manomano=[[0,15],[1,6],[0,8], [0,0],[0,13], [0,7],[2,17]]
    obs_manomano=[[-1,0,1,0,0],[-1,0,0,0,0],[6,0,0,0,0], [8,0,0,0,0], [0,1,0,0,0],[13,1,0,0,0], [7,1,0,0,0],[-1,1,0,0,0]]

    traj_manomano=types.Trajectory(obs_manomano, acts_manomano,None)


    acts_manomano_2=[[0,15],[1,6],[0,8], [0,0],[0,13], [0,7],[2,17]]
    obs_manomano_2=[[-1,1,1,0,0],[-1,1,0,0,0],[6,1,0,0,0], [8,1,0,0,0], [0,1,0,0,0],[13,1,0,0,0], [7,1,0,0,0],[-1,1,0,0,0]]

    traj_manomano_2=types.Trajectory(obs_manomano_2, acts_manomano_2,None)

    #-------------------------------------------------------------------------------------#
    
    acts_newegg=[[0,16],[1,6],[0,8], [0,0],[0,13], [0,7],[2,17]]
    obs_newegg=[[-1,0,1,0,0],[-1,0,0,0,0],[6,0,0,0,0], [8,0,0,0,0], [0,1,0,0,0],[13,1,0,0,0], [7,1,0,0,0],[-1,1,0,0,0]]

    traj_newegg=types.Trajectory(obs_newegg, acts_newegg,None)
    
    acts_newegg_2=[[0,16],[1,6],[0,8], [0,0],[0,13], [0,7],[2,17]]
    obs_newegg_2=[[-1,1,1,0,0],[-1,1,0,0,0],[6,1,0,0,0], [8,1,0,0,0], [0,1,0,0,0],[13,1,0,0,0], [7,1,0,0,0],[-1,1,0,0,0]]

    traj_newegg_2=types.Trajectory(obs_newegg_2, acts_newegg_2,None)

    acts_newegg=[[0,16],[1,6],[0,8], [0,0],[0,13], [0,7],[2,17]]
    obs_newegg=[[-1,0,1,0,1],[-1,0,0,0,1],[6,0,0,0,1], [8,0,0,0,1], [0,1,0,0,1],[13,1,0,0,1], [7,1,0,0,1],[-1,1,0,0,1]]

    traj_newegg_3=types.Trajectory(obs_newegg, acts_newegg,None)
    
    acts_newegg_2=[[0,16],[1,6],[0,8], [0,0],[0,13], [0,7],[2,17]]
    obs_newegg_2=[[-1,1,1,0,1],[-1,1,0,0,1],[6,1,0,0,1], [8,1,0,0,1], [0,1,0,0,1],[13,1,0,0,1], [7,1,0,0,1],[-1,1,0,0,1]]

    traj_newegg_4=types.Trajectory(obs_newegg_2, acts_newegg_2,None)

    #--------------------------------------------------------------------------------------#

    acts_barnesandnoble=[[0,15],[1,6],[0,8], [0,0],[0,13], [0,7],[2,17]]
    obs_barnesandnoble=[[-1,0,1,0,0],[-1,0,0,0,0],[6,0,0,0,0], [8,0,0,0,0], [0,1,0,0,0],[13,1,0,0,0], [7,1,0,0,0],[-1,1,0,0,0]]

    traj_barnesandnoble=types.Trajectory(obs_barnesandnoble, acts_barnesandnoble,None)
    
    acts_barnesandnoble_2=[[0,15],[1,6],[0,8], [0,0],[0,13], [0,7],[2,17]]
    obs_barnesandnoble_2=[[-1,1,1,0,0],[-1,1,0,0,0],[6,1,0,0,0], [8,1,0,0,0], [0,1,0,0,0],[13,1,0,0,0], [7,1,0,0,0],[-1,1,0,0,0]]

    traj_barnesandnoble_2=types.Trajectory(obs_barnesandnoble_2, acts_barnesandnoble_2,None)

    acts_barnesandnoble=[[0,15],[1,6],[0,8], [0,0],[0,13], [0,7],[2,17]]
    obs_barnesandnoble=[[-1,0,1,0,1],[-1,0,0,0,1],[6,0,0,0,1], [8,0,0,0,1], [0,1,0,0,1],[13,1,0,0,1], [7,1,0,0,1],[-1,1,0,0,1]]

    traj_barnesandnoble_3=types.Trajectory(obs_barnesandnoble, acts_barnesandnoble,None)
    
    acts_barnesandnoble_2=[[0,15],[1,6],[0,8], [0,0],[0,13], [0,7],[2,17]]
    obs_barnesandnoble_2=[[-1,1,1,0,1],[-1,1,0,0,1],[6,1,0,0,1], [8,1,0,0,1], [0,1,0,0,1],[13,1,0,0,1], [7,1,0,0,1],[-1,1,0,0,1]]

    traj_barnesandnoble_4=types.Trajectory(obs_barnesandnoble_2, acts_barnesandnoble_2,None)

    #--------------------------------------------------------------------------------------------#

    return np.array([traj_amazon,traj_alibris_books, traj_newegg, traj_barnesandnoble, traj_amazon_2, traj_alibris_books_2, traj_newegg_2, traj_barnesandnoble_2,traj_amazon_3, traj_alibris_books_3, traj_newegg_3, traj_barnesandnoble_3, traj_amazon_4, traj_alibris_books_4, traj_newegg_4, traj_barnesandnoble_4])

def menu():
    acts_abe=[[0,10], [0,8],[0,0],[0,7],[2,17]]
    obs_abe=[[-1,0,0,0,0], [10,0,0,0,0], [8,0,0,0,0],[0,1,0,0,0],[7,1,0,0,0],[-1,1,0,0,0]]

    traj_abe_books=types.Trajectory(obs_abe,acts_abe,None)
    
    acts_abe_2=[[0,10], [0,8],[0,0],[0,7],[2,17]]
    obs_abe_2=[[-1,1,0,0,0], [10,1,0,0,0], [8,1,0,0,0],[0,1,0,0,0],[7,1,0,0,0],[-1,1,0,0,0]]

    traj_abe_books_2=types.Trajectory(obs_abe_2,acts_abe_2,None)


    acts_abe=[[0,10], [0,8],[0,0],[0,7],[2,17]]
    obs_abe=[[-1,0,0,0,1], [10,0,0,0,1], [8,0,0,0,1],[0,1,0,0,1],[7,1,0,0,1],[-1,1,0,0,1]]

    traj_abe_books_3=types.Trajectory(obs_abe,acts_abe,None)
    
    acts_abe_2=[[0,10], [0,8],[0,0],[0,7],[2,17]]
    obs_abe_2=[[-1,1,0,0,1], [10,1,0,0,1], [8,1,0,0,1],[0,1,0,0,1],[7,1,0,0,1],[-1,1,0,0,1]]

    traj_abe_books_4=types.Trajectory(obs_abe_2,acts_abe_2,None)


    #------------------------------------------------------------------------------------------------#


    acts_alibris=[[0,10], [0,11],[0,0],[0,7],[2,17]]
    obs_alibris=[[-1,0,0,0,0], [10,0,0,0,0], [11,0,0,0,0],[0,1,0,0,0],[7,1,0,0,0],[-1,1,0,0,0]]

    traj_alibris=types.Trajectory(obs_alibris,acts_alibris,None)
    
    
    acts_alibris_2=[[0,10], [0,11],[0,0],[0,7],[2,17]]
    obs_alibris_2=[[-1,1,0,0,0], [10,1,0,0,0], [11,1,0,0,0],[0,1,0,0,0],[7,1,0,0,0],[-1,1,0,0,0]]

    traj_alibris_2=types.Trajectory(obs_alibris_2,acts_alibris_2,None)


    acts_alibris=[[0,10], [0,11],[0,0],[0,7],[2,17]]
    obs_alibris=[[-1,0,0,0,1], [10,0,0,0,1], [11,0,0,0,1],[0,1,0,0,1],[7,1,0,0,1],[-1,1,0,0,1]]

    traj_alibris_3=types.Trajectory(obs_alibris,acts_alibris,None)
    
    
    acts_alibris_2=[[0,10], [0,11],[0,0],[0,7],[2,17]]
    obs_alibris_2=[[-1,1,0,0,1], [10,1,0,0,1], [11,1,0,0,1],[0,1,0,0,1],[7,1,0,0,1],[-1,1,0,0,1]]

    traj_alibris_4=types.Trajectory(obs_alibris_2,acts_alibris_2,None)


    #---------------------------------------------------------------------------------------------#
    

    acts_amazon=[[0,9],[0,10], [0,11], [0,8], [0,0], [0,7],[2,17]]
    obs_amazon=[[-1,0,0,0,0],[9,0,0,0,0], [10,0,0,0,0],[11,0,0,0,0], [8,0,0,0,0], [0,1,0,0,0], [7,1,0,0,0],[-1,1,0,0,0]]

    traj_amazon=types.Trajectory(obs_amazon, acts_amazon,None)

    acts_amazon_2=[[0,9],[0,10], [0,11], [0,8], [0,0], [0,7],[2,17]]
    obs_amazon_2=[[-1,1,0,0,0],[9,1,0,0,0], [10,1,0,0,0],[11,1,0,0,0], [8,1,0,0,0], [0,1,0,0,0], [7,1,0,0,0],[-1,1,0,0,0]]

    traj_amazon_2=types.Trajectory(obs_amazon_2, acts_amazon_2,None)


    acts_amazon=[[0,9],[0,10], [0,11], [0,8], [0,0], [0,7],[2,17]]
    obs_amazon=[[-1,0,0,0,1],[9,0,0,0,1], [10,0,0,0,1],[11,0,0,0,1], [8,0,0,0,1], [0,1,0,0,1], [7,1,0,0,1],[-1,1,0,0,1]]

    traj_amazon_3=types.Trajectory(obs_amazon, acts_amazon,None)

    acts_amazon_2=[[0,9],[0,10], [0,11], [0,8], [0,0], [0,7],[2,17]]
    obs_amazon_2=[[-1,1,0,0,1],[9,1,0,0,1], [10,1,0,0,1],[11,1,0,0,1], [8,1,0,0,1], [0,1,0,0,1], [7,1,0,0,1],[-1,1,0,0,1]]

    traj_amazon_4=types.Trajectory(obs_amazon_2, acts_amazon_2,None)


    #---------------------------------------------------------------------------------------------#    
    

    acts_barnesandnoble=[[0,15],[0,10],[0,8], [0,0], [0,13],[0,7],[2,17]]
    obs_barnesandnoble=[[-1,0,1,0,0],[-1,0,0,0,0],[10,0,0,0,0], [8,0,0,0,0], [0,1,0,0,0],[13,1,0,0,0],[7,1,0,0,0],[-1,1,0,0,0]]

    traj_barnesandnoble=types.Trajectory(obs_barnesandnoble, acts_barnesandnoble,None)
    

    acts_barnesandnoble_2=[[0,15],[0,10],[0,8], [0,0], [0,13],[0,7],[2,17]]
    obs_barnesandnoble_2=[[-1,1,1,0,0],[-1,1,0,0,0],[10,1,0,0,0], [8,1,0,0,0], [0,1,0,0,0],[13,1,0,0,0],[7,1,0,0,0],[-1,1,0,0,0]]

    traj_barnesandnoble_2=types.Trajectory(obs_barnesandnoble_2, acts_barnesandnoble_2,None)



    #--------------------------------------------------------------------------------------------#


    acts_newegg=[[0,16],[0,10], [0,11] ,[0,8], [0,0],[0,16], [0,13],[0,16],[0,7],[2,17]]
    obs_newegg=[[-1,0,1,0,0],[-1,0,0,0,0],[10,0,0,0,0],[11,0,0,0,0],[8,0,0,0,0], [0,1,0,1,0],[0,1,0,0,0],[13,1,0,1,0],[13,1,0,0,0],[7,1,0,0,0],[-1,1,0,0,0]]

    traj_newegg=types.Trajectory(obs_newegg, acts_newegg,None)
    

    acts_newegg_2=[[0,16],[0,10], [0,11] ,[0,8], [0,0],[0,16], [0,13],[0,16],[0,7],[2,17]]
    obs_newegg_2=[[-1,1,1,0,0],[-1,1,0,0,0],[10,1,0,0,0],[11,1,0,0,0],[8,1,0,0,0], [0,1,0,1,0],[0,1,0,0,0],[13,1,0,1,0],[13,1,0,0,0],[7,1,0,0,0],[-1,1,0,0,0]]

    traj_newegg_2=types.Trajectory(obs_newegg_2, acts_newegg_2,None)


    acts_newegg=[[0,16],[0,10], [0,11] ,[0,8], [0,0],[0,16], [0,13],[0,16],[0,7],[2,17]]
    obs_newegg=[[-1,0,1,0,1],[-1,0,0,0,1],[10,0,0,0,1],[11,0,0,0,1],[8,0,0,0,1], [0,1,0,1,1],[0,1,0,0,1],[13,1,0,1,1],[13,1,0,0,1],[7,1,0,0,1],[-1,1,0,0,1]]

    traj_newegg_3=types.Trajectory(obs_newegg, acts_newegg,None)
    

    acts_newegg_2=[[0,16],[0,10], [0,11] ,[0,8], [0,0],[0,16], [0,13],[0,16],[0,7],[2,17]]
    obs_newegg_2=[[-1,1,1,0,0],[-1,1,0,0,1],[10,1,0,0,1],[11,1,0,0,1],[8,1,0,0,1], [0,1,0,1,1],[0,1,0,0,1],[13,1,0,1,1],[13,1,0,0,1],[7,1,0,0,1],[-1,1,0,0,1]]

    traj_newegg_4=types.Trajectory(obs_newegg_2, acts_newegg_2,None)



    #-------------------------------------------------------------------------------------------#


    acts_manomano=[[0,15],[0,9],[0,10],[0,11],[0,11], [0,8], [0,0], [0,13],[0,7],[2,17]]
    obs_manomano=[[-1,0,1,0,0],[-1,0,0,0,0],[9,0,0,0,0],[10,0,0,0,0],[11,0,0,0,0],[11,0,0,0,0],[8,0,0,0,0], [0,1,0,0,0],[13,1,0,0,0],[7,1,0,0,0],[-1,1,0,0,0]]

    traj_manomano=types.Trajectory(obs_manomano, acts_manomano,None)
    
    acts_manomano_2=[[0,15],[0,9],[0,10],[0,11],[0,11], [0,8], [0,0], [0,13],[0,7],[2,17]]
    obs_manomano_2=[[-1,1,1,0,0],[-1,1,0,0,0],[9,1,0,0,0],[10,1,0,0,0],[11,1,0,0,0],[11,1,0,0,0],[8,1,0,0,0], [0,1,0,0,0],[13,1,0,0,0],[7,1,0,0,0],[-1,1,0,0,0]]

    traj_manomano_2=types.Trajectory(obs_manomano_2, acts_manomano_2,None)


    acts_manomano=[[0,15],[0,9],[0,10],[0,11],[0,11], [0,8], [0,0], [0,13],[0,7],[2,17]]
    obs_manomano=[[-1,0,1,0,1],[-1,0,0,0,1],[9,0,0,0,1],[10,0,0,0,1],[11,0,0,0,1],[11,0,0,0,1],[8,0,0,0,1], [0,1,0,0,1],[13,1,0,0,1],[7,1,0,0,1],[-1,1,0,0,1]]

    traj_manomano_3=types.Trajectory(obs_manomano, acts_manomano,None)
    
    acts_manomano_2=[[0,15],[0,9],[0,10],[0,11],[0,11], [0,8], [0,0], [0,13],[0,7],[2,17]]
    obs_manomano_2=[[-1,1,1,0,1],[-1,1,0,0,1],[9,1,0,0,1],[10,1,0,0,1],[11,1,0,0,1],[11,1,0,0,1],[8,1,0,0,1], [0,1,0,0,1],[13,1,0,0,1],[7,1,0,0,1],[-1,1,0,0,1]]

    traj_manomano_4=types.Trajectory(obs_manomano_2, acts_manomano_2,None)


    #----------------------------------------------------------------------------------------------#

    return np.array([traj_abe_books,traj_alibris,traj_amazon, traj_manomano, traj_newegg, traj_abe_books_2, traj_alibris_2, traj_amazon_2, traj_manomano_2, traj_newegg_2, traj_abe_books_3, traj_alibris_3, traj_amazon_3, traj_manomano_3, traj_newegg_3, traj_abe_books_4, traj_alibris_4, traj_amazon_4, traj_manomano_4, traj_newegg_4])

def card():
    acts_abe=[[0,8],[0,0],[0,7],[2,17]]
    obs_abe=[[-1,0,0,0,0], [8,0,0,0,0],[0,1,0,0,0],[7,1,0,0,0],[-1,1,0,0,0]]

    traj_abe_books=types.Trajectory(obs_abe,acts_abe,None)
    
    acts_abe_2=[[0,8],[0,0],[0,7],[2,17]]
    obs_abe_2=[[-1,1,0,0,0], [8,1,0,0,0],[0,1,0,0,0],[7,1,0,0,0],[-1,1,0,0,0]]

    traj_abe_books_2=types.Trajectory(obs_abe_2,acts_abe_2,None)


    acts_abe=[[0,8],[0,0],[0,7],[2,17]]
    obs_abe=[[-1,0,0,0,1], [8,0,0,0,1],[0,1,0,0,1],[7,1,0,0,1],[-1,1,0,0,1]]

    traj_abe_books_3=types.Trajectory(obs_abe,acts_abe,None)
    
    acts_abe_2=[[0,8],[0,0],[0,7],[2,17]]
    obs_abe_2=[[-1,1,0,0,1], [8,1,0,0,1],[0,1,0,0,1],[7,1,0,0,1],[-1,1,0,0,1]]

    traj_abe_books_4=types.Trajectory(obs_abe_2,acts_abe_2,None)



    #----------------------------------------------------------------------------------------------#
    

    acts_alibris=[[0,8],[0,0],[0,7],[2,17]]
    obs_alibris=[[-1,0,0,0,0], [8,0,0,0,0],[0,1,0,0,0],[7,1,0,0,0],[-1,1,0,0,0]]

    traj_alibris=types.Trajectory(obs_alibris,acts_alibris,None)
    
    
    acts_alibris_2=[[0,8],[0,0],[0,7],[2,17]]
    obs_alibris_2=[[-1,1,0,0,0], [8,1,0,0,0],[0,1,0,0,0],[7,1,0,0,0],[-1,1,0,0,0]]

    traj_alibris_2=types.Trajectory(obs_alibris_2,acts_alibris_2,None)

    
    acts_alibris=[[0,8],[0,0],[0,7],[2,17]]
    obs_alibris=[[-1,0,0,0,1], [8,0,0,0,1],[0,1,0,0,1],[7,1,0,0,1],[-1,1,0,0,1]]

    traj_alibris_3=types.Trajectory(obs_alibris,acts_alibris,None)
    
    
    acts_alibris_2=[[0,8],[0,0],[0,7],[2,17]]
    obs_alibris_2=[[-1,1,0,0,1], [8,1,0,0,1],[0,1,0,0,1],[7,1,0,0,1],[-1,1,0,0,1]]

    traj_alibris_4=types.Trajectory(obs_alibris_2,acts_alibris_2,None)

    #----------------------------------------------------------------------------------------------#

    acts_amazon=[ [0,8], [0,0], [0,7],[2,17]]
    obs_amazon=[[-1,0,0,0,0], [8,0,0,0,0], [0,1,0,0,0], [7,1,0,0,0],[-1,1,0,0,0]]

    traj_amazon=types.Trajectory(obs_amazon, acts_amazon,None)

    acts_amazon_2=[ [0,8], [0,0], [0,7],[2,17]]
    obs_amazon_2=[[-1,1,0,0,0], [8,1,0,0,0], [0,1,0,0,0], [7,1,0,0,0],[-1,1,0,0,0]]

    traj_amazon_2=types.Trajectory(obs_amazon_2, acts_amazon_2,None)

    acts_amazon=[ [0,8], [0,0], [0,7],[2,17]]
    obs_amazon=[[-1,0,0,0,1], [8,0,0,0,1], [0,1,0,0,1], [7,1,0,0,1],[-1,1,0,0,1]]

    traj_amazon_3=types.Trajectory(obs_amazon, acts_amazon,None)

    acts_amazon_2=[ [0,8], [0,0], [0,7],[2,17]]
    obs_amazon_2=[[-1,1,0,0,1], [8,1,0,0,1], [0,1,0,0,1], [7,1,0,0,1],[-1,1,0,0,1]]

    traj_amazon_4=types.Trajectory(obs_amazon_2, acts_amazon_2,None)



    #----------------------------------------------------------------------------------------------#


    acts_manomano=[[0,15], [0,8], [0,0], [0,13],[0,7],[2,17]]
    obs_manomano=[[-1,0,1,0,0],[-1,0,0,0,0], [8,0,0,0,0], [0,1,0,0,0],[13,1,0,0,0],[7,1,0,0,0],[-1,1,0,0,0]]

    traj_manomano=types.Trajectory(obs_manomano, acts_manomano,None)
    
    acts_manomano_2=[[0,15], [0,8], [0,0], [0,13],[0,7],[2,17]]
    obs_manomano_2=[[-1,1,1,0,0],[-1,1,0,0,0], [8,1,0,0,0], [0,1,0,0,0],[13,1,0,0,0],[7,1,0,0,0],[-1,1,0,0,0]]

    traj_manomano_2=types.Trajectory(obs_manomano_2, acts_manomano_2,None)

    acts_manomano=[[0,15], [0,8], [0,0], [0,13],[0,7],[2,17]]
    obs_manomano=[[-1,0,1,0,1],[-1,0,0,0,1], [8,0,0,0,1], [0,1,0,0,1],[13,1,0,0,1],[7,1,0,0,1],[-1,1,0,0,1]]

    traj_manomano_3=types.Trajectory(obs_manomano, acts_manomano,None)
    
    acts_manomano_2=[[0,15], [0,8], [0,0], [0,13],[0,7],[2,17]]
    obs_manomano_2=[[-1,1,1,0,1],[-1,1,0,0,1], [8,1,0,0,1], [0,1,0,0,1],[13,1,0,0,1],[7,1,0,0,1],[-1,1,0,0,1]]

    traj_manomano_4=types.Trajectory(obs_manomano_2, acts_manomano_2,None)

    #----------------------------------------------------------------------------------------------#
    

    acts_barnesandnoble=[[0,15], [0,8], [0,0], [0,13],[0,7],[2,17]]
    obs_barnesandnoble=[[-1,0,1,0,0],[-1,0,0,0,0], [8,0,0,0,0], [0,1,0,0,0],[13,1,0,0,0],[7,1,0,0,0],[-1,1,0,0,0]]

    traj_barnesandnoble=types.Trajectory(obs_barnesandnoble, acts_barnesandnoble,None)
    
    acts_barnesandnoble_2=[[0,15], [0,8], [0,0], [0,13],[0,7],[2,17]]
    obs_barnesandnoble_2=[[-1,1,1,0,0],[-1,1,0,0,0], [8,1,0,0,0], [0,1,0,0,0],[13,1,0,0,0],[7,1,0,0,0],[-1,1,0,0,0]]

    traj_barnesandnoble_2=types.Trajectory(obs_barnesandnoble_2, acts_barnesandnoble_2,None)

    #----------------------------------------------------------------------------------------------#

    acts_newegg=[[0,16], [0,8], [0,0],[0,16], [0,13],[0,16],[0,7],[2,17]]
    obs_newegg=[[-1,0,1,0,0],[-1,0,0,0,0], [8,0,0,0,0], [0,1,0,1,0],[0,1,0,0,0],[13,1,0,1,0],[13,1,0,0,0],[7,1,0,0,0],[-1,1,0,0,0]]

    traj_newegg=types.Trajectory(obs_newegg, acts_newegg,None)
    
    acts_newegg_2=[[0,16], [0,8], [0,0],[0,16], [0,13],[0,16],[0,7],[2,17]]
    obs_newegg_2=[[-1,1,1,0,0],[-1,1,0,0,0], [8,1,0,0,0], [0,1,0,1,0],[0,1,0,0,0],[13,1,0,1,0],[13,1,0,0,0],[7,1,0,0,0],[-1,1,0,0,0]]

    traj_newegg_2=types.Trajectory(obs_newegg_2, acts_newegg_2,None)

    acts_newegg=[[0,16], [0,8], [0,0],[0,16], [0,13],[0,16],[0,7],[2,17]]
    obs_newegg=[[-1,0,1,0,1],[-1,0,0,0,1], [8,0,0,0,1], [0,1,0,1,1],[0,1,0,0,1],[13,1,0,1,1],[13,1,0,0,1],[7,1,0,0,1],[-1,1,0,0,1]]

    traj_newegg_3=types.Trajectory(obs_newegg, acts_newegg,None)
    
    acts_newegg_2=[[0,16], [0,8], [0,0],[0,16], [0,13],[0,16],[0,7],[2,17]]
    obs_newegg_2=[[-1,1,1,0,1],[-1,1,0,0,1], [8,1,0,0,1], [0,1,0,1,1],[0,1,0,0,1],[13,1,0,1,1],[13,1,0,0,1],[7,1,0,0,1],[-1,1,0,0,1]]

    traj_newegg_4=types.Trajectory(obs_newegg_2, acts_newegg_2,None)

    #----------------------------------------------------------------------------------------------#

    return np.array([traj_abe_books,traj_alibris,traj_amazon, traj_manomano, traj_newegg,traj_abe_books_2,traj_alibris_2,traj_amazon_2, traj_manomano_2, traj_newegg_2,traj_abe_books_3,traj_alibris_3,traj_amazon_3, traj_manomano_3, traj_newegg_3, traj_abe_books_4,traj_alibris_4,traj_amazon_4, traj_manomano_4, traj_newegg_4])

def login():
    acts_abe=[[0,1], [1,2], [1,3],[0,1],[2,17]]
    obs_abe=[[-1,0,0,0,0], [1,0,0,0,0], [2,0,0,0,0], [3,0,0,0,0], [1,0,0,0,1],[-1,0,0,0,1]]

    traj_abe_books=types.Trajectory(obs_abe,acts_abe,None)
    
    acts_abe_2=[[0,1], [1,2], [1,3],[0,1],[2,17]]
    obs_abe_2=[[-1,1,0,0,0], [1,1,0,0,0], [2,1,0,0,0], [3,1,0,0,0], [1,1,0,0,1],[-1,1,0,0,1]]

    traj_abe_books_2=types.Trajectory(obs_abe_2,acts_abe_2,None)

    acts_alibris=[[0,7], [1,2], [1,3],[0,1],[2,17]]
    obs_alibris=[[-1,0,0,0,0], [7,0,0,0,0], [2,0,0,0,0], [3,0,0,0,0], [1,0,0,0,1],[-1,0,0,0,1]]

    traj_alibris=types.Trajectory(obs_alibris,acts_alibris,None)
    
    acts_alibris_2=[[0,7], [1,2], [1,3],[0,1],[2,17]]
    obs_alibris_2=[[-1,1,0,0,0], [7,1,0,0,0], [2,1,0,0,0], [3,1,0,0,0], [1,1,0,0,1],[-1,1,0,0,1]]

    traj_alibris_2=types.Trajectory(obs_alibris_2,acts_alibris_2,None)

    acts_amazon=[[0,5],[1,2], [0,4], [1,3], [0,1],[2,17]]
    obs_amazon=[[-1,0,0,0,0],[5,0,0,0,0], [2,0,0,0,0], [4,0,0,0,0], [3,0,0,0,0], [1,0,0,0,1],[-1,0,0,0,1]]

    traj_amazon=types.Trajectory(obs_amazon, acts_amazon,None)
    
    acts_amazon_2=[[0,5],[1,2], [0,4], [1,3], [0,1],[2,17]]
    obs_amazon_2=[[-1,1,0,0,0],[5,1,0,0,0], [2,1,0,0,0], [4,1,0,0,0], [3,1,0,0,0], [1,1,0,0,1],[-1,1,0,0,1]]

    traj_amazon_2=types.Trajectory(obs_amazon_2, acts_amazon_2,None)

    acts_manomano=[[0,15],[0,5],[1,2], [1,3], [0,1],[2,17]]
    obs_manomano=[[-1,0,1,0,0],[-1,0,0,0,0],[5,0,0,0,0], [2,0,0,0,0], [3,0,0,0,0], [1,0,0,0,1],[-1,0,0,0,1]]

    traj_manomano=types.Trajectory(obs_manomano, acts_manomano,None)
    
    acts_manomano_2=[[0,15],[0,5],[1,2], [1,3], [0,1],[2,17]]
    obs_manomano_2=[[-1,1,1,0,0],[-1,1,0,0,0],[5,1,0,0,0], [2,1,0,0,0], [3,1,0,0,0], [1,1,0,0,1],[-1,1,0,0,1]]

    traj_manomano_2=types.Trajectory(obs_manomano_2, acts_manomano_2,None)

    acts_newegg=[[0,16],[0,1],[1,2],[0,1], [1,3], [0,1],[2,17]]
    obs_newegg=[[-1,0,1,0,0],[-1,0,0,0,0],[1,0,0,0,0], [2,0,0,0,0],[1,0,0,0,0], [3,0,0,0,0], [1,0,0,0,1],[-1,0,0,0,1]]

    traj_newegg=types.Trajectory(obs_newegg, acts_newegg,None)
    
    acts_newegg_2=[[0,16],[0,1],[1,2],[0,1], [1,3], [0,1],[2,17]]
    obs_newegg_2=[[-1,1,1,0,0],[-1,1,0,0,0],[1,1,0,0,0], [2,1,0,0,0],[1,1,0,0,0], [3,1,0,0,0], [1,1,0,0,1],[-1,1,0,0,1]]

    traj_newegg_2=types.Trajectory(obs_newegg_2, acts_newegg_2,None)

    acts_barnesandnoble=[[0,16],[0,5],[0,1],[1,2], [1,3], [0,1],[2,17]]
    obs_barnesandnoble=[[-1,0,1,0,0],[-1,0,0,0,0],[5,0,0,0,0],[1,0,0,0,0], [2,0,0,0,0], [3,0,0,0,0], [1,0,0,0,1],[-1,0,0,0,1]]

    traj_barnesandnoble=types.Trajectory(obs_barnesandnoble, acts_barnesandnoble,None)
    
    acts_barnesandnoble_2=[[0,16],[0,5],[0,1],[1,2], [1,3], [0,1],[2,17]]
    obs_barnesandnoble_2=[[-1,1,1,0,0],[-1,1,0,0,0],[5,1,0,0,0],[1,1,0,0,0], [2,1,0,0,0], [3,1,0,0,0], [1,1,0,0,1],[-1,1,0,0,1]]

    traj_barnesandnoble_2=types.Trajectory(obs_barnesandnoble_2, acts_barnesandnoble_2,None)

    return np.array([traj_abe_books, traj_alibris, traj_amazon, traj_manomano, traj_newegg, traj_barnesandnoble,traj_abe_books_2, traj_alibris_2, traj_amazon_2, traj_manomano_2, traj_newegg_2, traj_barnesandnoble_2])

def remove():
    acts_abe=[[0,8],[0,0],[0,12],[2,17]]
    obs_abe=[[-1,0,0,0,0],[8,0,0,0,0],[0,1,0,0,0],[12,0,0,0,0],[-1,0,0,0,0]]

    traj_abe_books=types.Trajectory(obs_abe,acts_abe,None)
    
    acts_abe_2=[[0,8],[0,0],[0,12],[2,17]]
    obs_abe_2=[[-1,1,0,0,0],[8,1,0,0,0],[0,1,0,0,0],[12,0,0,0,0],[-1,0,0,0,0]]

    traj_abe_books_2=types.Trajectory(obs_abe_2,acts_abe_2,None)

    acts_abe=[[0,8],[0,0],[0,12],[2,17]]
    obs_abe=[[-1,0,0,0,1],[8,0,0,0,1],[0,1,0,0,1],[12,0,0,0,1],[-1,0,0,0,1]]

    traj_abe_books_3=types.Trajectory(obs_abe,acts_abe,None)
    
    acts_abe_2=[[0,8],[0,0],[0,12],[2,17]]
    obs_abe_2=[[-1,1,0,0,1],[8,1,0,0,1],[0,1,0,0,1],[12,0,0,0,1],[-1,0,0,0,1]]

    traj_abe_books_4=types.Trajectory(obs_abe_2,acts_abe_2,None)

    #----------------------------------------------------------------------------------------------#

    acts_amazon=[ [0,8], [0,0],[0,13],[0,12],[2,17]]
    obs_amazon=[[-1,0,0,0,0],[8,0,0,0,0], [0,1,0,0,0],[13,1,0,0,0], [12,0,0,0,0],[-1,0,0,0,0]]

    traj_amazon=types.Trajectory(obs_amazon, acts_amazon,None)
    
    acts_amazon_2=[ [0,8], [0,0],[0,13],[0,12],[2,17]]
    obs_amazon_2=[[-1,1,0,0,0],[8,1,0,0,0], [0,1,0,0,0],[13,1,0,0,0], [12,0,0,0,0],[-1,0,0,0,0]]

    traj_amazon_2=types.Trajectory(obs_amazon_2, acts_amazon_2,None)

    acts_amazon=[ [0,8], [0,0],[0,13],[0,12],[2,17]]
    obs_amazon=[[-1,0,0,0,1],[8,0,0,0,1], [0,1,0,0,1],[13,1,0,0,1], [12,0,0,0,1],[-1,0,0,0,1]]

    traj_amazon_3=types.Trajectory(obs_amazon, acts_amazon,None)
    
    acts_amazon_2=[ [0,8], [0,0],[0,13],[0,12],[2,17]]
    obs_amazon_2=[[-1,1,0,0,1],[8,1,0,0,1], [0,1,0,0,1],[13,1,0,0,1], [12,0,0,0,1],[-1,0,0,0,1]]

    traj_amazon_4=types.Trajectory(obs_amazon_2, acts_amazon_2,None)

    #----------------------------------------------------------------------------------------------#


    acts_alibris=[[0,8],[0,0],[0,13],[0,12],[2,17]]
    obs_alibris=[[-1,0,0,0,0],[8,0,0,0,0],[0,1,0,0,0],[13,1,0,0,0],[12,0,0,0,0],[-1,0,0,0,0]]

    traj_alibris=types.Trajectory(obs_alibris,acts_alibris,None)
    
    acts_alibris_2=[[0,8],[0,0],[0,13],[0,12],[2,17]]
    obs_alibris_2=[[-1,1,0,0,0],[8,1,0,0,0],[0,1,0,0,0],[13,1,0,0,0],[12,0,0,0,0],[-1,0,0,0,0]]

    traj_alibris_2=types.Trajectory(obs_alibris_2,acts_alibris_2,None)

    acts_alibris=[[0,8],[0,0],[0,13],[0,12],[2,17]]
    obs_alibris=[[-1,0,0,0,1],[8,0,0,0,1],[0,1,0,0,1],[13,1,0,0,1],[12,0,0,0,1],[-1,0,0,0,1]]

    traj_alibris_3=types.Trajectory(obs_alibris,acts_alibris,None)
    
    acts_alibris_2=[[0,8],[0,0],[0,13],[0,12],[2,17]]
    obs_alibris_2=[[-1,1,0,0,1],[8,1,0,0,1],[0,1,0,0,1],[13,1,0,0,1],[12,0,0,0,1],[-1,0,0,0,1]]

    traj_alibris_4=types.Trajectory(obs_alibris_2,acts_alibris_2,None)

   #----------------------------------------------------------------------------------------------#


    acts_barnesandnoble=[[0,15], [0,8], [0,0], [0,13],[0,12],[2,17]]
    obs_barnesandnoble=[[-1,0,1,0,0],[-1,0,0,0,0], [8,0,0,0,0], [0,1,0,0,0],[13,1,0,0,0],[12,0,0,0,0],[-1,0,0,0,0]]

    traj_barnesandnoble=types.Trajectory(obs_barnesandnoble, acts_barnesandnoble,None)
    
    acts_barnesandnoble_2=[[0,15], [0,8], [0,0], [0,13],[0,12],[2,17]]
    obs_barnesandnoble_2=[[-1,1,1,0,0],[-1,1,0,0,0], [8,1,0,0,0], [0,1,0,0,0],[13,1,0,0,0],[12,0,0,0,0],[-1,0,0,0,0]]

    traj_barnesandnoble_2=types.Trajectory(obs_barnesandnoble_2, acts_barnesandnoble_2,None)

    
    acts_barnesandnoble=[[0,15], [0,8], [0,0], [0,13],[0,12],[2,17]]
    obs_barnesandnoble=[[-1,0,1,0,1],[-1,0,0,0,1], [8,0,0,0,1], [0,1,0,0,1],[13,1,0,0,1],[12,0,0,0,1],[-1,0,0,0,1]]

    traj_barnesandnoble_3=types.Trajectory(obs_barnesandnoble, acts_barnesandnoble,None)
    
    acts_barnesandnoble_2=[[0,15], [0,8], [0,0], [0,13],[0,12],[2,17]]
    obs_barnesandnoble_2=[[-1,1,1,0,1],[-1,1,0,0,1], [8,1,0,0,1], [0,1,0,0,1],[13,1,0,0,1],[12,0,0,0,1],[-1,0,0,0,1]]

    traj_barnesandnoble_4=types.Trajectory(obs_barnesandnoble_2, acts_barnesandnoble_2,None)
    
   #----------------------------------------------------------------------------------------------#

    acts_newegg=[[0,16], [0,8], [0,0],[0,16], [0,13],[0,16],[0,12],[2,17]]
    obs_newegg=[[-1,0,1,0,0],[-1,0,0,0,0], [8,0,0,0,0], [0,1,0,1,0],[0,1,0,0,0],[13,1,0,1,0],[13,1,0,0,0],[12,0,0,0,0],[-1,0,0,0,0]]

    traj_newegg=types.Trajectory(obs_newegg, acts_newegg,None)
    
    acts_newegg_2=[[0,16], [0,8], [0,0],[0,16], [0,13],[0,16],[0,12],[2,17]]
    obs_newegg_2=[[-1,1,1,0,0],[-1,1,0,0,0], [8,1,0,0,0], [0,1,0,1,0],[0,1,0,0,0],[13,1,0,1,0],[13,1,0,0,0],[12,0,0,0,0],[-1,0,0,0,0]]

    traj_newegg_2=types.Trajectory(obs_newegg_2, acts_newegg_2,None)

    acts_newegg=[[0,16], [0,8], [0,0],[0,16], [0,13],[0,16],[0,12],[2,17]]
    obs_newegg=[[-1,0,1,0,1],[-1,0,0,0,1], [8,0,0,0,1], [0,1,0,1,1],[0,1,0,0,1],[13,1,0,1,1],[13,1,0,0,1],[12,0,0,0,1],[-1,0,0,0,1]]

    traj_newegg_3=types.Trajectory(obs_newegg, acts_newegg,None)
    
    acts_newegg_2=[[0,16], [0,8], [0,0],[0,16], [0,13],[0,16],[0,12],[2,17]]
    obs_newegg_2=[[-1,1,1,0,1],[-1,1,0,0,1], [8,1,0,0,1], [0,1,0,1,1],[0,1,0,0,1],[13,1,0,1,1],[13,1,0,0,1],[12,0,0,0,1],[-1,0,0,0,1]]

    traj_newegg_4=types.Trajectory(obs_newegg_2, acts_newegg_2,None)

   #----------------------------------------------------------------------------------------------#

    acts_manomano=[[0,15], [0,8], [0,0], [0,13],[0,12],[2,17]]
    obs_manomano=[[-1,0,1,0,0],[-1,0,0,0,0], [8,0,0,0,0], [0,1,0,0,0],[13,1,0,0,0],[12,0,0,0,0],[-1,0,0,0,0]]

    traj_manomano=types.Trajectory(obs_manomano, acts_manomano,None)
    
    acts_manomano_2=[[0,15], [0,8], [0,0], [0,13],[0,12],[2,17]]
    obs_manomano_2=[[-1,1,1,0,0],[-1,1,0,0,0], [8,1,0,0,0], [0,1,0,0,0],[13,1,0,0,0],[12,0,0,0,0],[-1,0,0,0,0]]

    traj_manomano_2=types.Trajectory(obs_manomano_2, acts_manomano_2,None)

    
    acts_manomano=[[0,15], [0,8], [0,0], [0,13],[0,12],[2,17]]
    obs_manomano=[[-1,0,1,0,1],[-1,0,0,0,1], [8,0,0,0,1], [0,1,0,0,1],[13,1,0,0,1],[12,0,0,0,1],[-1,0,0,0,1]]

    traj_manomano_3=types.Trajectory(obs_manomano, acts_manomano,None)
    
    acts_manomano_2=[[0,15], [0,8], [0,0], [0,13],[0,12],[2,17]]
    obs_manomano_2=[[-1,1,1,0,1],[-1,1,0,0,1], [8,1,0,0,1], [0,1,0,0,1],[13,1,0,0,1],[12,0,0,0,1],[-1,0,0,0,1]]

    traj_manomano_4=types.Trajectory(obs_manomano_2, acts_manomano_2,None)

   #----------------------------------------------------------------------------------------------#
    return np.array([traj_abe_books, traj_amazon,traj_newegg,traj_barnesandnoble, traj_abe_books_2, traj_amazon_2,traj_newegg_2,traj_barnesandnoble_2, traj_abe_books_3, traj_amazon_3,traj_newegg_3,traj_barnesandnoble_3, traj_abe_books_4, traj_amazon_4,traj_newegg_4,traj_barnesandnoble_4])

def main():
    search_traj= search()
    menu_traj= menu()
    card_traj= card()
    login_traj=login()
    remove_traj=remove()

    arr=np.concatenate((search_traj,menu_traj,card_traj, login_traj,remove_traj))

    file=open('expert_all.pkl', 'wb')
    pickle.dump(arr, file, pickle.HIGHEST_PROTOCOL)

main()