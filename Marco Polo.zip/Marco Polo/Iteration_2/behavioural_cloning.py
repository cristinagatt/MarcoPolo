import pathlib
import pickle
import tempfile

import stable_baselines3 as sb3
from stable_baselines3.common.vec_env import DummyVecEnv

from web_env.envs.web_env import Web_Env 

from imitation.algorithms import bc
from imitation.data import rollout
from imitation.util import logger,util

with open("expert_combined_remove_from_cart.pkl","rb") as f:
    trajectories=pickle.load(f)


transitions=rollout.flatten_trajectories(trajectories)
venv= DummyVecEnv([lambda : Web_Env()])

tempdir=tempfile.TemporaryDirectory(prefix="quickstart")
tempdir_path= pathlib.Path(tempdir.name)


logger.configure(tempdir_path/"BC")
bc_trainer=bc.BC(venv.observation_space, venv.action_space, expert_data=transitions)
bc_trainer.train(n_epochs=50000)

bc_trainer.save_policy("combined_remove_from_cart_policy")